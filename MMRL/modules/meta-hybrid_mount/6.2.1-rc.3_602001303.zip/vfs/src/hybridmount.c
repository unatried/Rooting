// SPDX-License-Identifier: GPL-2.0-only
//
// Hybrid Mount VFS path redirection subsystem, forked from NoMount
// (https://github.com/maxsteeel/nomount). Upstream copyright is retained; see
// PROVENANCE and LICENSE in this directory.

#include <linux/init.h>
#include <linux/fs.h>
#include <linux/file.h>
#include <linux/namei.h>
#include <linux/cred.h>
#include <linux/xattr.h>
#include <linux/module.h>
#include "hybridmount.h"

/*** Helpers ***/

static __always_inline bool hybridmount_is_uid_blocked(uid_t target_uid)
{
    struct hm_uid_array *arr;
    bool blocked = false;
    rcu_read_lock();
    if ((arr = rcu_dereference(hybridmount_uids))) {
        int lo = 0, hi = arr->count;
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            uid_t value = READ_ONCE(arr->uids[mid]);
            if (value == target_uid) { blocked = true; break; }
            if (value < target_uid) lo = mid + 1; else hi = mid;
        }
    }
    rcu_read_unlock();
    return blocked;
}


static __always_inline struct hybridmount_rule *hybridmount_bsearch_child(struct hybridmount_child_array *arr, const char *name, size_t len, u32 hash, int *index)
{
    int l = 0, n = arr->count;
    u32 *hashes = arr->hashes;
    struct hybridmount_rule **rules = hm_get_child_rules(arr);

    while (n > 0) {
        int step = n >> 1, m = l + step, less = (hashes[m] < hash), mask = -less;
        l += (step + 1) & mask;
        n = step + ((n - (step << 1) - 1) & mask);
    }
    if (index) *index = l;
    while (l < arr->count && hashes[l] == hash) {
        struct hybridmount_rule *rule = READ_ONCE(rules[l]);
        if (likely(rule && rule->child_len == len) && !memcmp(hm_get_child_name(rule), name, len)) {
            if (index) *index = l;
            return rule;
        }
        l++;
    }
    return NULL;
}

static bool __hybridmount_get_rule_info(struct hybridmount_dir_node *dir_node, const char *name, size_t len, u32 hash, struct hm_rule_info *rule_info, bool get_path)
{
    void *children;
    struct hybridmount_rule *rule, *found_rule;
    unsigned int seq;
    uid_t fsuid = current_fsuid().val;

    do {
        found_rule = NULL;
        seq = read_seqcount_begin(&dir_node->seq);
        if (likely((children = rcu_dereference(dir_node->children)))) {
            if (hm_children_is_single(children)) {
                rule = hm_children_single_rule(children);
                if (rule->child_len != len || memcmp(hm_get_child_name(rule), name, len)) rule = NULL;
            } else {
                rule = hybridmount_bsearch_child(children, name, len, hash, NULL);
            }
            if (rule && (!rule->target_uid || rule->target_uid == fsuid))
                found_rule = rule;
        }
    } while (read_seqcount_retry(&dir_node->seq, seq));

    if (!found_rule) return false;

    if (likely(rule_info)) {
        rule_info->flags = found_rule->flags;
        rule_info->v_ino = found_rule->v_ino;
        rule_info->this_dir = found_rule->this_dir;
        if (found_rule->flags & HM_FLAG_VIRTUAL_DIR) {
            rule_info->r_path = (struct path){ .dentry = NULL, .mnt = NULL };
        } else {
            rule_info->r_path = (get_path && found_rule->r_path.dentry) ? found_rule->r_path : (struct path){ .dentry = NULL, .mnt = NULL };
            if (rule_info->r_path.dentry) path_get(&rule_info->r_path);
        }
    }

    return true;
}

static bool hybridmount_get_rule_info(struct hybridmount_dir_node *dir_node, const char *name, size_t len, u32 hash, struct hm_rule_info *rule_info, bool get_path)
{
    bool found;
    if (unlikely(!dir_node)) return false;
    rcu_read_lock();
    found = __hybridmount_get_rule_info(dir_node, name, len, hash, rule_info, get_path);
    rcu_read_unlock();
    return found;
}

static void hm_dir_rcu_free(struct rcu_head *head)
{
    struct hybridmount_dir_node *dir = container_of(head, struct hybridmount_dir_node, rcu);
    void *children = rcu_dereference_raw(dir->children);
    if (!hm_children_is_single(children)) kfree(children);
    kfree(dir);
}

static inline void hm_destroy_virtual_inode(struct inode *inode)
{
    struct hm_inode_info *info = inode->i_private;
    if (!info) return;
    if (info->r_path.dentry) path_put(&info->r_path);

    if (info->dir_node) {
        WRITE_ONCE(info->dir_node->v_inode, NULL);
        if (hm_dir_tag(info->dir_node) == 1UL)
            call_rcu(&info->dir_node->rcu, hm_dir_rcu_free);
    }

    kfree(info);
    inode->i_private = NULL;
}

static inline void hm_destroy_hijacked_inode(struct inode *inode, bool restore)
{
    struct hm_iop *hm_iop = hm_get_hm_iop(inode->i_op);
    struct hm_fop *hm_fop = hm_get_hm_fop(inode->i_fop);
    struct hybridmount_dir_node *dir_node = hm_iop ? hm_iop->dir_node : (hm_fop ? hm_fop->dir_node : NULL);

    if (hm_iop) {
        if (dir_node) RCU_INIT_POINTER(dir_node->iop, NULL);
        if (restore) smp_store_release(&inode->i_op, hm_iop->orig_iop);
        kfree_rcu(hm_iop, rcu);
    }
    if (hm_fop) {
        if (dir_node) RCU_INIT_POINTER(dir_node->fop, NULL);
        if (restore) smp_store_release(&inode->i_fop, hm_fop->orig_fop);
        kfree_rcu(hm_fop, rcu);
    }
    if (dir_node && !hm_dir_is_virtual(dir_node)) {
        smp_mb();
        if (!rcu_access_pointer(dir_node->children) &&
             cmpxchg(&dir_node->v_inode, NULL, (struct inode *)-1L) == NULL)
                call_rcu(&dir_node->rcu, hm_dir_rcu_free);
    }
}

struct hybridmount_proxy_ctx {
    struct dir_context ctx;
    struct dir_context *orig_ctx;
    struct hybridmount_dir_node *dir_node;
    bool emitted;
    bool uid_blocked;
};

static HM_ACTOR_RET hybridmount_actor_proxy(struct dir_context *ctx, const char *name, int namelen,
                                        loff_t offset, u64 ino, unsigned int d_type)
{
    struct hybridmount_proxy_ctx *proxy = container_of(ctx, struct hybridmount_proxy_ctx, ctx);
    HM_ACTOR_RET ret;

    if (proxy->dir_node && !proxy->uid_blocked) {
        u32 hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, name, namelen);
        if ((READ_ONCE(proxy->dir_node->bloom_mask) & (1ULL << (hash & 63))) &&
            hybridmount_get_rule_info(proxy->dir_node, name, namelen, hash, NULL, false)) {
            proxy->ctx.pos = offset;
            return HM_ACTOR_CONTINUE;
        }
    }

    proxy->orig_ctx->pos = proxy->ctx.pos;
    ret = proxy->orig_ctx->actor(proxy->orig_ctx, name, namelen, offset, ino, d_type);
    proxy->ctx.pos = proxy->orig_ctx->pos;
    proxy->emitted = true;

    return ret;
}

static inline void hybridmount_emit_virtual_children(struct dir_context *ctx, struct hybridmount_dir_node *dir_node)
{
	struct hybridmount_child_array *array;
	void *children;
	uid_t fsuid = current_fsuid().val;
	int id, srcu_idx;

	if (!dir_node || hybridmount_is_uid_blocked(fsuid)) return;
	if (!hm_is_virtual_pos(ctx->pos)) ctx->pos = hm_pack_pos(0);
	srcu_idx = srcu_read_lock(&hybridmount_srcu);
	children = srcu_dereference(dir_node->children, &hybridmount_srcu);
	if (children) {
		struct hybridmount_rule *single = hm_children_is_single(children) ? hm_children_single_rule(children) : NULL;
		struct hybridmount_rule **rules;
		array = single ? NULL : children;
		rules = array ? hm_get_child_rules(array) : &single;
		for (id = hm_unpack_pos(ctx->pos); id < (array ? READ_ONCE(array->count) : 1); id++) {
			struct hybridmount_rule *rule;
			ctx->pos = hm_pack_pos(id);
			if ((rule = READ_ONCE(rules[id])) && (rule->target_uid == 0 || rule->target_uid == fsuid)) {
				if (!(rule->flags & HM_FLAG_WHITEOUT) && !dir_emit(ctx, hm_get_child_name(rule), rule->child_len, rule->v_hash,
						(rule->flags & HM_FLAG_IS_DIR) ? DT_DIR : DT_REG)) break;
			}
			ctx->pos = hm_pack_pos(id + 1);
		}
	}
	srcu_read_unlock(&hybridmount_srcu, srcu_idx);
}

static void hybridmount_init_prealloc_inode(struct inode *inode, struct hm_inode_info *info, struct hm_rule_info *rule_info)
{
    struct inode *r_inode = NULL;
    info->flags = rule_info->flags;
    info->dir_node = rule_info->this_dir;
    if (rule_info->flags & HM_FLAG_VIRTUAL_DIR) {
        info->r_path = (struct path){ .dentry = NULL, .mnt = NULL };
    } else {
        info->r_path = rule_info->r_path.dentry ? rule_info->r_path : (struct path){ .dentry = NULL, .mnt = NULL };
        r_inode = info->r_path.dentry ? d_backing_inode(info->r_path.dentry) : NULL;
    }

    inode->i_ino = rule_info->v_ino;
    inode->i_private = info;
    inode->i_mode   = r_inode ? r_inode->i_mode    : (S_IFDIR | 0755);
    inode->i_size   = r_inode ? i_size_read(r_inode) : 4096;
    inode->i_blocks = r_inode ? r_inode->i_blocks  : 8;
    inode->i_uid    = r_inode ? r_inode->i_uid     : GLOBAL_ROOT_UID;
    inode->i_gid    = r_inode ? r_inode->i_gid     : GLOBAL_ROOT_GID;
    inode->i_op     = (r_inode && !S_ISDIR(r_inode->i_mode)) ? &hm_file_iops : &hm_dir_iops;

    if (r_inode && !S_ISDIR(r_inode->i_mode))
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 16, 0)
        inode->i_fop = (r_inode->i_fop && r_inode->i_fop->mmap_prepare) ? &hm_file_fops_mmap_prepare : &hm_file_fops;
#else
        inode->i_fop = &hm_file_fops;
#endif
    else
        inode->i_fop = &hm_dir_fops;

    if (r_inode) hm_sync_inode_times(inode, r_inode), inode->i_mapping = r_inode->i_mapping;
    inode->i_flags |= S_PRIVATE | S_NOATIME | S_NOCMTIME | S_NOSEC;
    if (!S_ISLNK(inode->i_mode)) inode->i_opflags |= IOP_NOFOLLOW;
}

static struct dentry *hybridmount_resolve_rule_dentry(struct inode *dir, struct dentry *dentry, struct hybridmount_dir_node *dir_node, u32 hash)
{
    struct hm_inode_info *prealloc_info = NULL;
    struct inode *splice_inode = NULL, *prealloc_inode = NULL;
    struct dentry *res = ERR_PTR(-ENODATA);
    struct hm_rule_info rule_info = {0};

    rcu_read_lock();
    if (!dir_node || !__hybridmount_get_rule_info(dir_node, dentry->d_name.name, dentry->d_name.len, hash, &rule_info, false))
        goto unlock_out;
    if (rule_info.flags & HM_FLAG_WHITEOUT)
        goto resolve_rule;
    rcu_read_unlock();

    if (likely((prealloc_inode = new_inode(dir->i_sb)))) {
        if (unlikely(!(prealloc_info = kmalloc(sizeof(*prealloc_info), GFP_KERNEL)))) {
            iput(prealloc_inode);
            prealloc_inode = NULL;
        }
    }

    rcu_read_lock();
    if (unlikely(!__hybridmount_get_rule_info(dir_node, dentry->d_name.name, dentry->d_name.len, hash, &rule_info, true)))
        goto unlock_out;

resolve_rule:
    if (unlikely(hybridmount_is_uid_blocked(current_fsuid().val)))
        goto unlock_out;

    if (rule_info.flags & HM_FLAG_WHITEOUT) {
        hybridmount_hijack_dentry_ops(dir, dentry, true);
        d_add(dentry, NULL); res = NULL;
        goto unlock_out;
    }

    if (likely(prealloc_inode && ((rule_info.flags & HM_FLAG_VIRTUAL_DIR) || rule_info.r_path.dentry))) {
        if (rule_info.this_dir && (splice_inode = cmpxchg(&rule_info.this_dir->v_inode, NULL, prealloc_inode))) {
            if (splice_inode == (struct inode *)-1L) goto unlock_out;
            igrab(splice_inode);
        } else {
            hybridmount_init_prealloc_inode(prealloc_inode, prealloc_info, &rule_info);
            splice_inode = prealloc_inode;
            prealloc_inode = NULL; prealloc_info = NULL;
            rule_info.r_path.dentry = NULL; 
        }

        rcu_read_unlock();
        if (!IS_ERR((res = d_splice_alias(splice_inode, dentry))))
            hybridmount_hijack_dentry_ops(dir, res ? res : dentry, true);
            
        goto cleanup_out;
    }

unlock_out:
    rcu_read_unlock();
cleanup_out:
    if (rule_info.r_path.dentry) 
        path_put(&rule_info.r_path);

    if (prealloc_inode) {
        kfree(prealloc_info);
        iput(prealloc_inode);
    }    
    return res;
}

/*** i_op / s_op / f_op Hijacking Hooks ***/

static struct dentry *hybridmount_hijacked_lookup(struct inode *dir, struct dentry *dentry, unsigned int flags)
{
    struct hm_iop *hm_iop = hm_get_hm_iop(smp_load_acquire(&dir->i_op));
    struct hybridmount_dir_node *dir_node = hm_iop ? READ_ONCE(hm_iop->dir_node) : NULL;
    struct dentry *res;
    u32 hash = 0;
    bool is_blocked = false;

    if (unlikely(!hm_iop || !dir_node))
        goto do_real_lookup;

    hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, dentry->d_name.name, dentry->d_name.len);
    /* The bloom filter is the cheap gate: only a potential rule is worth the uid
     * isolation lookup. A miss means no rule carries this name, so the dentry-drop
     * in the real-lookup path could not trigger either. */
    if (likely(!(READ_ONCE(dir_node->bloom_mask) & (1ULL << (hash & 63)))))
        goto do_real_lookup;

    if (unlikely((is_blocked = hybridmount_is_uid_blocked(current_fsuid().val))))
        goto do_real_lookup;

    if ((res = hybridmount_resolve_rule_dentry(dir, dentry, dir_node, hash)) != ERR_PTR(-ENODATA))
        return res;

do_real_lookup:
    if (likely(hm_iop && hm_iop->orig_iop && hm_iop->orig_iop->lookup)) {
        res = hm_iop->orig_iop->lookup(dir, dentry, flags);
        if (dir_node && !is_blocked) {
            if (!hash) hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, dentry->d_name.name, dentry->d_name.len);
            if (unlikely(hybridmount_get_rule_info(dir_node, dentry->d_name.name, dentry->d_name.len, hash, NULL, false))) {
                struct dentry *target = res ? res : dentry;
                if (!IS_ERR(target)) d_drop(target);
            }
        }
        if (!IS_ERR(res ? res : dentry)) hybridmount_hijack_dentry_ops(dir, res ? res : dentry, false);
        return res;
    }
    return ERR_PTR(-EOPNOTSUPP);
}

static int hybridmount_hijacked_iterate_dir(struct file *file, struct dir_context *ctx)
{
    struct hm_fop *hm_fop = hm_get_hm_fop(smp_load_acquire(&file->f_op));
    struct hybridmount_dir_node *dir_node = hm_fop ? READ_ONCE(hm_fop->dir_node) : NULL;
    const struct file_operations *orig_fop = hm_fop ? hm_fop->orig_fop : NULL;
    struct hybridmount_proxy_ctx proxy_ctx = { .ctx.actor = hybridmount_actor_proxy };
    bool is_blocked = hybridmount_is_uid_blocked(current_fsuid().val);
    int res = 0;

    if (unlikely(!orig_fop || !dir_node))
        goto do_real_iterate;

    if (unlikely(hm_is_virtual_pos(ctx->pos))) {
        if (likely(!is_blocked)) hybridmount_emit_virtual_children(ctx, dir_node);
        return 0;
    }

    if (unlikely(is_blocked || !READ_ONCE(dir_node->bloom_mask)))
        goto do_real_iterate;

    proxy_ctx.ctx.pos = ctx->pos;
    proxy_ctx.orig_ctx = ctx;
    proxy_ctx.dir_node = dir_node;
    proxy_ctx.emitted = false;
    proxy_ctx.uid_blocked = is_blocked;

    res = hm_call_iterate(file, &proxy_ctx.ctx, orig_fop);
    ctx->pos = proxy_ctx.ctx.pos;
    
    if (res < 0 || proxy_ctx.emitted)
        return res;

    ctx->pos = hm_pack_pos(0);
    hybridmount_emit_virtual_children(ctx, dir_node);
    return res;

do_real_iterate:
    if (likely(orig_fop)) 
        return hm_call_iterate(file, ctx, orig_fop);
    return -ENOTDIR;
}

static void hybridmount_hijacked_destroy_inode(struct inode *inode)
{
    struct hm_sop *hm_sop;
    (inode->i_op == &hm_file_iops || inode->i_op == &hm_dir_iops) ? hm_destroy_virtual_inode(inode) : hm_destroy_hijacked_inode(inode, false);

    hm_sop = hm_get_hm_sop(smp_load_acquire(&inode->i_sb->s_op));
    if (hm_sop && hm_sop->orig_sop && hm_sop->orig_sop->destroy_inode)
        hm_sop->orig_sop->destroy_inode(inode);
}

static int hybridmount_hijacked_drop_inode(struct inode *inode)
{
    struct hm_sop *hm_sop;
    if (inode->i_op == &hm_file_iops || inode->i_op == &hm_dir_iops) goto generic_fn;

    hm_sop = hm_get_hm_sop(smp_load_acquire(&inode->i_sb->s_op));
    if (hm_sop && hm_sop->orig_sop && hm_sop->orig_sop->drop_inode)
        return hm_sop->orig_sop->drop_inode(inode);

generic_fn:
    return !inode->i_nlink || inode_unhashed(inode);
}

static void hybridmount_hijacked_evict_inode(struct inode *inode)
{
    struct hm_sop *hm_sop;
    if (inode->i_op == &hm_file_iops || inode->i_op == &hm_dir_iops) goto generic_fn;

    hm_sop = hm_get_hm_sop(smp_load_acquire(&inode->i_sb->s_op));
    if (hm_sop && hm_sop->orig_sop && hm_sop->orig_sop->evict_inode) {
        hm_sop->orig_sop->evict_inode(inode);
    } else {
generic_fn:
        truncate_inode_pages_final(&inode->i_data);
        clear_inode(inode);
    }
}

/*** file / inode / superblock operations ***/

static int hm_open(struct inode *inode, struct file *file)
{
    struct hm_inode_info *info = inode->i_private;
    struct file *real_file;

    if (unlikely(!info)) return -ENODEV;
    if (unlikely(info->flags & HM_FLAG_VIRTUAL_DIR)) {
        file->private_data = NULL;
        return 0;
    }
    if (unlikely(!info->r_path.dentry)) return -ENODEV;

    real_file = dentry_open(&info->r_path, (file->f_flags & ~(O_CREAT | O_EXCL | O_NOCTTY)), file->f_cred);
    if (IS_ERR(real_file)) return PTR_ERR(real_file);

    file->private_data = real_file;
    return 0;
}

static int hm_release(struct inode *inode, struct file *file)
{
    struct file *real_file = file->private_data;
    if (real_file) fput(real_file), file->private_data = NULL;
    return 0;
}

static loff_t hm_llseek(struct file *file, loff_t offset, int whence)
{
    struct file *real_file = file->private_data;
    loff_t res;
    if (!real_file) return -EINVAL;

    real_file->f_pos = file->f_pos;
    res = vfs_llseek(real_file, offset, whence);
    file->f_pos = real_file->f_pos;

    return res;
}

static ssize_t hm_read_iter(struct kiocb *iocb, struct iov_iter *to)
{
    struct file *file = iocb->ki_filp;
    struct file *real_file = file->private_data;
    ssize_t ret;
    if (!real_file || !real_file->f_op->read_iter) return -EINVAL;

    iocb->ki_filp = real_file;
    ret = real_file->f_op->read_iter(iocb, to);
    iocb->ki_filp = file;

    return ret;
}

static ssize_t hm_write_iter(struct kiocb *iocb, struct iov_iter *from)
{
    struct file *file = iocb->ki_filp;
    struct file *real_file = file->private_data;
    ssize_t ret;
    if (!real_file || !real_file->f_op->write_iter) return -EINVAL;

    iocb->ki_filp = real_file;
    ret = real_file->f_op->write_iter(iocb, from);
    iocb->ki_filp = file;

    return ret;
}

static int hm_mmap(struct file *file, struct vm_area_struct *vma)
{
    int ret = generic_file_mmap(file, vma);
    return ret ? ret : (file_inode(file)->i_flags &= ~S_PRIVATE, 0);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 16, 0)
static int hm_mmap_prepare(struct vm_area_desc *desc)
{
    int ret = generic_file_mmap_prepare(desc);
    return ret ? ret : (file_inode(desc->file)->i_flags &= ~S_PRIVATE, 0);
}
#endif

static long hm_unlocked_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct file *real_file = file->private_data;
    if (!real_file || !real_file->f_op->unlocked_ioctl) return -ENOTTY;
    return real_file->f_op->unlocked_ioctl(real_file, cmd, arg);
}

#ifdef CONFIG_COMPAT
static long hm_compat_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    struct file *real_file = file->private_data;
    if (!real_file || !real_file->f_op->compat_ioctl) return -ENOTTY;
    return real_file->f_op->compat_ioctl(real_file, cmd, arg);
}
#endif

static ssize_t hm_splice_read(struct file *in, loff_t *ppos, struct pipe_inode_info *pipe,
                              size_t len, unsigned int flags)
{
    struct file *real_file = in->private_data;
    if (!real_file || !real_file->f_op->splice_read) return -EINVAL;
    return real_file->f_op->splice_read(real_file, ppos, pipe, len, flags);
}

static ssize_t hm_splice_write(struct pipe_inode_info *pipe, struct file *out,
                               loff_t *ppos, size_t len, unsigned int flags)
{
    struct file *real_file = out->private_data;
    if (!real_file || !real_file->f_op->splice_write) return -EINVAL;
    return real_file->f_op->splice_write(pipe, real_file, ppos, len, flags);
}

static int hm_fsync(struct file *file, loff_t start, loff_t end, int datasync)
{
    struct file *real_file = file->private_data;
    if (!real_file || !real_file->f_op->fsync) return -EINVAL;
    return real_file->f_op->fsync(real_file, start, end, datasync);
}

static ssize_t hm_listxattr(struct dentry *dentry, char *buffer, size_t size)
{
    struct hm_inode_info *info = d_backing_inode(dentry)->i_private;
    struct inode *r_inode;

    if (unlikely(!info)) return -EIO;
    if (info->flags & HM_FLAG_VIRTUAL_DIR) return 0;
    if (!info->r_path.dentry) return -EOPNOTSUPP;

    r_inode = d_backing_inode(info->r_path.dentry);
    if (!r_inode || !r_inode->i_op || !r_inode->i_op->listxattr) return 0;
    return r_inode->i_op->listxattr(info->r_path.dentry, buffer, size);
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 11, 0)
static int hm_getattr(struct vfsmount *mnt, struct dentry *dentry, struct kstat *stat)
#else
static int hm_getattr(IDMAP_ARG const struct path *path, struct kstat *stat, u32 request_mask, unsigned int query_flags)
#endif
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 11, 0)
    struct dentry *dentry = path->dentry;
#endif
    struct inode *v_inode = d_backing_inode(dentry);
    struct hm_inode_info *info = v_inode->i_private;
    int res = 0;

    if (unlikely(!info)) return -EIO;
    if (unlikely(info->flags & HM_FLAG_VIRTUAL_DIR))
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 3, 0)
        generic_fillattr(IDMAP_CALL request_mask, v_inode, stat);
#else
        generic_fillattr(IDMAP_CALL v_inode, stat);
#endif
    else
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 11, 0)
        res = vfs_getattr_nosec(&info->r_path, stat);
#else
        res = vfs_getattr_nosec(&info->r_path, stat, request_mask, query_flags);
#endif

    if (likely(res == 0)) {
        stat->ino = v_inode->i_ino;
        stat->dev = v_inode->i_sb->s_dev;
    }
    
    return res;
}

static int hm_setattr(IDMAP_ARG struct dentry *dentry, struct iattr *attr)
{
    struct inode *v_inode = d_inode(dentry);
    struct hm_inode_info *info = v_inode->i_private;
    struct inode *r_inode;
    int err;

    if (unlikely(!info)) return -EIO;
    if (info->flags & HM_FLAG_VIRTUAL_DIR) return 0;

    r_inode = d_backing_inode(info->r_path.dentry);
    inode_lock(r_inode);
    err = notify_change(IDMAP_CALL info->r_path.dentry, attr, NULL);
    inode_unlock(r_inode);

    if (likely(!err)) {
        if (attr->ia_valid & ATTR_SIZE) i_size_write(v_inode, i_size_read(r_inode));
        if (attr->ia_valid & ATTR_MODE) v_inode->i_mode = r_inode->i_mode;
        if (attr->ia_valid & ATTR_UID)  v_inode->i_uid = r_inode->i_uid;
        if (attr->ia_valid & ATTR_GID)  v_inode->i_gid = r_inode->i_gid;
        hm_sync_inode_times(v_inode, r_inode);
    }
    return err;
}

static const char *hm_get_link(struct dentry *dentry, struct inode *inode, struct delayed_call *done)
{
    struct hm_inode_info *info = inode->i_private;
    struct inode *real_inode;
    struct dentry *target_dentry;
    if (unlikely(!info || !info->r_path.dentry)) return ERR_PTR(-ECHILD);

    real_inode = d_backing_inode(info->r_path.dentry);
    target_dentry = dentry ? info->r_path.dentry : NULL;
    if (real_inode && real_inode->i_op && real_inode->i_op->get_link) {
        return real_inode->i_op->get_link(target_dentry, real_inode, done);
    }

    return ERR_PTR(-EINVAL);
}

static int hm_dir_iterate_dir(struct file *file, struct dir_context *ctx)
{
    struct hm_inode_info *info = file_inode(file)->i_private;
    struct hybridmount_dir_node *dir_node = info ? info->dir_node : NULL;
    struct file *real_file = file->private_data;
    int res = 0;
    if (unlikely(hm_is_virtual_pos(ctx->pos))) goto emit_virtual;

    if (real_file) {
        struct hybridmount_proxy_ctx proxy_ctx = {
            .ctx.actor = hybridmount_actor_proxy, .ctx.pos = ctx->pos, .orig_ctx = ctx,
            .dir_node = dir_node, .emitted = false, .uid_blocked = hybridmount_is_uid_blocked(current_fsuid().val)
        };
        res = hm_call_iterate(real_file, &proxy_ctx.ctx, real_file->f_op);
        ctx->pos = proxy_ctx.ctx.pos;
        if (res < 0 || proxy_ctx.emitted) return res;
        ctx->pos = hm_pack_pos(0);
    } else if (info && (info->flags & HM_FLAG_VIRTUAL_DIR)) {
        if (ctx->pos < 2 && !dir_emit_dots(file, ctx)) return 0;
        ctx->pos = hm_pack_pos(0);
    } else {
        return -ENOTDIR;
    }

emit_virtual:
    hybridmount_emit_virtual_children(ctx, dir_node);
    return res;
}

static struct dentry *hm_dir_lookup(struct inode *dir, struct dentry *dentry, unsigned int flags)
{
    struct hm_inode_info *info = dir->i_private; 
    struct dentry *res;

    if (info->dir_node) {
        u32 v_hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, dentry->d_name.name, dentry->d_name.len);
        if (READ_ONCE(info->dir_node->bloom_mask) & (1ULL << (v_hash & 63)) &&
            (res = hybridmount_resolve_rule_dentry(dir, dentry, info->dir_node, v_hash)) != ERR_PTR(-ENODATA))
                return res;
    }

    if (info->flags & HM_FLAG_VIRTUAL_DIR)
        goto negative_dentry;

    if (info->r_path.dentry) {
        struct inode *r_dir = d_backing_inode(info->r_path.dentry);
        if (r_dir->i_op->lookup) {
            res = r_dir->i_op->lookup(r_dir, dentry, flags);
            if (!IS_ERR(res ? res : dentry)) hybridmount_hijack_dentry_ops(dir, res ? res : dentry, false);
            return res;
        }
    }
    return ERR_PTR(-EOPNOTSUPP);

negative_dentry:
    hybridmount_hijack_dentry_ops(dir, dentry, true);
    d_add(dentry, NULL);
    return NULL;
}

struct hm_xattr_proxy {
    struct xattr_handler fake;
    const struct xattr_handler *orig;
};

static int hm_xattr_get(const struct xattr_handler *handler, struct dentry *dentry, struct inode *inode, const char *name, void *buffer, size_t size FLAGS_ARG)
{
    struct hm_xattr_proxy *proxy = container_of(handler, struct hm_xattr_proxy, fake);
    if (inode->i_op == &hm_file_iops || inode->i_op == &hm_dir_iops) {
        struct hm_inode_info *info = inode->i_private;
        if (unlikely(!info || !info->r_path.dentry)) return -ENODATA;
        return __vfs_getxattr(info->r_path.dentry, d_inode(info->r_path.dentry), xattr_full_name(handler, name), buffer, size FLAGS_VAL);
    }

    return proxy->orig->get(proxy->orig, dentry, inode, name, buffer, size FLAGS_VAL);
}

static int hm_xattr_set(const struct xattr_handler *handler, IDMAP_ARG struct dentry *dentry, struct inode *inode, const char *name, const void *buffer, size_t size, int flags)
{
    struct hm_xattr_proxy *proxy = container_of(handler, struct hm_xattr_proxy, fake);
    if (inode->i_op == &hm_file_iops || inode->i_op == &hm_dir_iops) {
        struct hm_inode_info *info = inode->i_private;
        if (unlikely(!info || !info->r_path.dentry)) return -ENODATA;
        return __vfs_setxattr(IDMAP_PATH(info->r_path) info->r_path.dentry, d_inode(info->r_path.dentry), xattr_full_name(handler, name), buffer, size, flags);
    }
    return proxy->orig->set(proxy->orig, IDMAP_CALL dentry, inode, name, buffer, size, flags);
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
static int hm_d_revalidate(struct inode *parent_inode, const struct qstr *name, struct dentry *dentry, unsigned int flags)
#else
static int hm_d_revalidate(struct dentry *dentry, unsigned int flags)
#endif
{
    struct hybridmount_dir_node *parent_dir = NULL;
    const struct dentry_operations *orig_dops;
    struct hm_rule_info rule_info;
    struct inode *inode;
    struct hm_iop *iop = NULL;
    bool injected, has_rule = false;

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 13, 0)
    struct inode *parent_inode = d_inode(READ_ONCE(dentry->d_parent));
    const struct qstr *name = &dentry->d_name;
#endif
    if (unlikely(!parent_inode)) return 1;

    if (parent_inode->i_op == &hm_dir_iops) {
        parent_dir = ((struct hm_inode_info *)parent_inode->i_private)->dir_node;
    } else {
        iop = hm_get_hm_iop(smp_load_acquire(&parent_inode->i_op));
        parent_dir = iop ? iop->dir_node : NULL;
    }

    inode = READ_ONCE(dentry->d_inode);
    injected = inode && (inode->i_op == &hm_file_iops || inode->i_op == &hm_dir_iops);

    if (parent_dir) {
        u32 hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, name->name, name->len);
        has_rule = hybridmount_get_rule_info(parent_dir, name->name, name->len, hash, &rule_info, false);
    }

    if (hybridmount_is_uid_blocked(current_fsuid().val)) {
        if (injected) goto drop_it;
        goto orig_dops;
    }

    if (has_rule) {
        if (rule_info.flags & HM_FLAG_WHITEOUT) return !inode;
        if (injected) return 1;
        goto drop_it;
    }

    if (injected || (!inode && has_rule))
        goto drop_it;

orig_dops:
    if ((orig_dops = hm_get_orig_dops(iop)) && orig_dops->d_revalidate) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
        return orig_dops->d_revalidate(parent_inode, name, dentry, flags);
#else
        return orig_dops->d_revalidate(dentry, flags);
#endif
    }
    return 1;

drop_it:
    if (flags & LOOKUP_RCU) return -ECHILD;
    d_drop(dentry);
    return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 16, 0)
static const struct file_operations hm_file_fops_mmap_prepare = {
    .owner = THIS_MODULE,
    .llseek = hm_llseek,
    .open = hm_open,
    .release = hm_release,
    .read_iter = hm_read_iter,
    .write_iter = hm_write_iter,
    .mmap_prepare = hm_mmap_prepare,
    .unlocked_ioctl = hm_unlocked_ioctl,
#ifdef CONFIG_COMPAT
    .compat_ioctl = hm_compat_ioctl,
#endif
    .splice_read = hm_splice_read,
    .splice_write = hm_splice_write,
    .fsync = hm_fsync,
};
#endif

static const struct file_operations hm_file_fops = {
    .owner = THIS_MODULE,
    .llseek = hm_llseek,
    .open = hm_open,
    .release = hm_release,
    .read_iter = hm_read_iter,
    .write_iter = hm_write_iter,
    .mmap = hm_mmap,
    .unlocked_ioctl = hm_unlocked_ioctl,
#ifdef CONFIG_COMPAT
    .compat_ioctl = hm_compat_ioctl,
#endif
    .splice_read = hm_splice_read,
    .splice_write = hm_splice_write,
    .fsync = hm_fsync,
};

static const struct inode_operations hm_file_iops = {
    .getattr = hm_getattr,
    .setattr = hm_setattr,
    .listxattr = hm_listxattr,
    .get_link = hm_get_link,
};

static const struct file_operations hm_dir_fops = {
    .owner = THIS_MODULE,
    .open = hm_open,
    .release = hm_release,
    .llseek = default_llseek,
    .read = generic_read_dir,
    .iterate_shared = hm_dir_iterate_dir,
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)
    .iterate = hm_dir_iterate_dir,
#endif
};

static const struct inode_operations hm_dir_iops = {
    .lookup = hm_dir_lookup,
    .getattr = hm_getattr,
    .setattr = hm_setattr,
    .listxattr = hm_listxattr,
};

/* --- Hijacking Management --- */

static inline void hybridmount_hijack_superblock(struct super_block *sb)
{
    struct hm_sop *hm_sop;
    int count = 0;

    if (unlikely(!sb || !sb->s_op || hm_get_hm_sop(smp_load_acquire(&sb->s_op)) ||
                 !(hm_sop = kmalloc(sizeof(*hm_sop), GFP_KERNEL)))) return;

    hm_sop->fake_sop = *(sb->s_op);
    hm_sop->orig_sop = sb->s_op;
    hm_sop->orig_xattr = hm_sop->fake_xattr = NULL;
    hm_sop->sb = sb;
    hm_sop->fake_sop.destroy_inode = hybridmount_hijacked_destroy_inode;
    hm_sop->fake_sop.drop_inode = hybridmount_hijacked_drop_inode;
    hm_sop->fake_sop.evict_inode = hybridmount_hijacked_evict_inode;

    if (sb->s_xattr) {
        const struct xattr_handler **new_array;
        struct hm_xattr_proxy *proxies;

        while (sb->s_xattr[count]) count++;
        if ((new_array = kmalloc((count + 1) * sizeof(void *) + (count * sizeof(*proxies)), GFP_KERNEL))) {
            proxies = (void *)(new_array + count + 1);
            new_array[count] = NULL;
            for (int i = 0; i < count; i++) {
                proxies[i].orig = sb->s_xattr[i];
                proxies[i].fake = *sb->s_xattr[i];
                if (proxies[i].fake.get) proxies[i].fake.get = hm_xattr_get;
                if (proxies[i].fake.set) proxies[i].fake.set = hm_xattr_set;
                new_array[i] = &proxies[i].fake;
            }
            hm_sop->orig_xattr = (const struct xattr_handler **)sb->s_xattr;
            hm_sop->fake_xattr = new_array;
            smp_store_release((const struct xattr_handler ***)&sb->s_xattr, new_array);
            hm_debug("xattr handlers successfully hijacked for dev: 0x%x\n", sb->s_dev);
        }
    }

    list_add_tail_rcu(&hm_sop->list, &hybridmount_sb_list);
    smp_store_release(&sb->s_op, &hm_sop->fake_sop);
    hm_debug("Superblock successfully hijacked for dev: 0x%x\n", sb->s_dev);
}

static inline void hybridmount_hijack_dir_ops(struct hybridmount_dir_node *dir_node, struct inode *inode)
{
    struct hm_iop *hm_iop = NULL;
    struct hm_fop *hm_fop = NULL;

    if (inode->i_op && !hm_get_hm_iop(smp_load_acquire(&inode->i_op))) {
        if (likely((hm_iop = kmalloc(sizeof(*hm_iop), GFP_KERNEL)))) {
            hm_iop->fake_iop = *(inode->i_op);
            hm_iop->orig_iop = inode->i_op;
            hm_iop->dir_node = dir_node;
            hm_iop->orig_dops = NULL;

            hm_iop->fake_iop.lookup = hybridmount_hijacked_lookup;
            rcu_assign_pointer(dir_node->iop, hm_iop);
            smp_store_release(&inode->i_op, &hm_iop->fake_iop);
        }
    }

    if (inode->i_fop && !hm_get_hm_fop(smp_load_acquire(&inode->i_fop))) {
        if (likely((hm_fop = kmalloc(sizeof(*hm_fop), GFP_KERNEL)))) {
            hm_fop->fake_fop = *(inode->i_fop);
            hm_fop->orig_fop = inode->i_fop;
            hm_fop->dir_node = dir_node;

            if (inode->i_fop->iterate_shared)
                hm_fop->fake_fop.iterate_shared = hybridmount_hijacked_iterate_dir;
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)
            if (hm_fop->fake_fop.iterate)
                hm_fop->fake_fop.iterate = hybridmount_hijacked_iterate_dir;
#endif
            rcu_assign_pointer(dir_node->fop, hm_fop);
            smp_store_release(&inode->i_fop, &hm_fop->fake_fop);
        }
    }

    if (hm_iop || hm_fop) hm_debug("Successfully hijacked VFS ops for parent dir (ino: %lu)\n", (unsigned long)inode->i_ino);
}

static void hybridmount_hijack_dentry_ops(struct inode *dir, struct dentry *dentry, bool injected)
{
    static const struct dentry_operations hm_dops = { .d_revalidate = hm_d_revalidate };
    const struct dentry_operations *orig, *current_orig;
    struct hm_iop *iop;

    if (!dentry || !dir) return;
    iop = hm_get_hm_iop(smp_load_acquire(&dir->i_op));
    if ((orig = READ_ONCE(dentry->d_op)) == &hm_dops || (iop && orig == &iop->fake_dops)) return;

    spin_lock(&dentry->d_lock);
    if ((orig = dentry->d_op) == &hm_dops || (iop && orig == &iop->fake_dops)) { spin_unlock(&dentry->d_lock); return; }
    if (orig && iop) {
        if (unlikely((current_orig = smp_load_acquire(&iop->orig_dops)) != orig)) {
            if (current_orig == NULL) {
                if (cmpxchg(&iop->orig_dops, NULL, HM_DOP_INITIALIZING) == NULL) {
                    iop->fake_dops = *orig;
                    iop->fake_dops.d_revalidate = hm_d_revalidate;
                    smp_store_release(&iop->orig_dops, orig);
                } else {
                    while (smp_load_acquire(&iop->orig_dops) == HM_DOP_INITIALIZING) cpu_relax();
                }
            } else if (current_orig == HM_DOP_INITIALIZING) {
                while (smp_load_acquire(&iop->orig_dops) == HM_DOP_INITIALIZING) cpu_relax();
            }
        }
        dentry->d_op = &iop->fake_dops;
    } else {
        dentry->d_op = &hm_dops;
    }

    if (injected)
        dentry->d_flags |= (DCACHE_OP_REVALIDATE | DCACHE_DONTCACHE);

    spin_unlock(&dentry->d_lock);
}

static void hybridmount_restore_superblocks(void)
{
    struct hm_sop *hm_sop, *tmp;
    struct inode *inode;
    list_for_each_entry_safe(hm_sop, tmp, &hybridmount_sb_list, list) {
        if (hm_sop->sb) {
            shrink_dcache_sb(hm_sop->sb);
            spin_lock(&hm_sop->sb->s_inode_list_lock);
            list_for_each_entry(inode, &hm_sop->sb->s_inodes, i_sb_list) {
                if (!inode->i_op && !inode->i_fop) continue;
                hm_destroy_hijacked_inode(inode, true);
            }
            spin_unlock(&hm_sop->sb->s_inode_list_lock);
            smp_store_release(&hm_sop->sb->s_op, hm_sop->orig_sop);
            if (hm_sop->fake_xattr) {
                smp_store_release((const struct xattr_handler ***)&hm_sop->sb->s_xattr, hm_sop->orig_xattr);
                kfree(hm_sop->fake_xattr); 
            }
            hm_debug("Successfully cured superblock for dev: 0x%x\n", hm_sop->sb->s_dev);
        }
        list_del_rcu(&hm_sop->list);
        kfree_rcu(hm_sop, rcu);
    }
}

/*** Module Management ***/

static struct hybridmount_dir_node *__hybridmount_alloc_dir_node(void)
{
    struct hybridmount_dir_node *dir_node = kzalloc(sizeof(*dir_node), GFP_KERNEL);
    if (unlikely(!dir_node)) return NULL;
    seqcount_init(&dir_node->seq); 
    return dir_node;
}

static int __hybridmount_inject_child_locked(struct hybridmount_dir_node *dir_node, struct hybridmount_rule *rule, const char *name, size_t name_len)
{
    struct hybridmount_child_array *new_arr, *old_arr;
    struct hybridmount_rule **new_rules, **old_rules, *single;
    void *children;
    int old_count, capacity, new_cap, pos = 0;
    u32 target_hash, single_hash, *old_hashes;

    if (unlikely(!dir_node)) return -EINVAL;

    rule->child_len = name_len;
    rule->parent_dir = dir_node;
    target_hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, name, name_len);
    children = rcu_dereference_protected(dir_node->children, lockdep_is_held(&hybridmount_rwsem));
    single = hm_children_is_single(children) ? hm_children_single_rule(children) : NULL;
    old_arr = single ? NULL : children;
    if (!children || (single && single->child_len == name_len && !memcmp(hm_get_child_name(single), name, name_len))) {
        write_seqcount_begin(&dir_node->seq);
        rcu_assign_pointer(dir_node->children, hm_children_from_single(rule));
        dir_node->bloom_mask |= (1ULL << (target_hash & 63));
        write_seqcount_end(&dir_node->seq);
        return 0;
    }
    if (old_arr && hybridmount_bsearch_child(old_arr, name, name_len, target_hash, &pos)) {
        write_seqcount_begin(&dir_node->seq);
        WRITE_ONCE(hm_get_child_rules(old_arr)[pos], rule);
        write_seqcount_end(&dir_node->seq);
        return 0;
    }
    old_count = old_arr ? old_arr->count : 1;
    capacity = old_arr ? old_arr->capacity : 0;
    old_rules = old_arr ? hm_get_child_rules(old_arr) : &single;
    if (single) {
        single_hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, hm_get_child_name(single), single->child_len);
        pos = single_hash < target_hash;
    }
    old_hashes = old_arr ? old_arr->hashes : &single_hash;

    if (old_count < capacity) {
        write_seqcount_begin(&dir_node->seq);
        if (pos < old_count) {
            for (int i = old_count; i > pos; i--) {
                WRITE_ONCE(old_arr->hashes[i], READ_ONCE(old_arr->hashes[i - 1]));
                WRITE_ONCE(old_rules[i], READ_ONCE(old_rules[i - 1]));
            }
        }
        WRITE_ONCE(old_arr->hashes[pos], target_hash);
        WRITE_ONCE(old_rules[pos], rule);
        old_arr->count++;
        dir_node->bloom_mask |= (1ULL << (target_hash & 63));
        write_seqcount_end(&dir_node->seq);
        return 0;
    }

    new_cap = capacity == 0 ? 4 : capacity * 2;
    if (!(new_arr = kmalloc(sizeof(*new_arr) + (new_cap * sizeof(u32)) + (new_cap * sizeof(*new_rules)), GFP_KERNEL))) {
        rule->parent_dir = NULL;
        return -ENOMEM;
    }
    new_arr->capacity = new_cap;
    new_arr->count = old_count + 1;
    new_rules = hm_get_child_rules(new_arr);
    memcpy(new_arr->hashes, old_hashes, pos * sizeof(u32));
    memcpy(new_rules, old_rules, pos * sizeof(*new_rules));
    memcpy(&new_arr->hashes[pos + 1], &old_hashes[pos], (old_count - pos) * sizeof(u32));
    memcpy(&new_rules[pos + 1], &old_rules[pos], (old_count - pos) * sizeof(*new_rules));
    new_arr->hashes[pos] = target_hash;
    new_rules[pos] = rule;

    write_seqcount_begin(&dir_node->seq);
    rcu_assign_pointer(dir_node->children, new_arr);
    dir_node->bloom_mask |= (1ULL << (target_hash & 63));
    write_seqcount_end(&dir_node->seq);

    if (old_arr) {
        synchronize_srcu(&hybridmount_srcu);
        kfree_rcu(old_arr, rcu);
    }
    return 0;
}

static struct hybridmount_dir_node *__hybridmount_delete_child_locked(struct hybridmount_rule *rule)
{
    struct hybridmount_dir_node *dir_node = rule->parent_dir;
    struct hybridmount_dir_node *parent = dir_node && hm_dir_is_virtual(dir_node) ? dir_node : NULL;
    struct hybridmount_child_array *old_arr;
    struct hybridmount_rule **rules, *single;
    void *children;
    int old_count, target_idx = -1;
    u64 mask = 0;

    if (unlikely(!dir_node || !(children = rcu_dereference_protected(dir_node->children, lockdep_is_held(&hybridmount_rwsem))))) return parent;
    single = hm_children_is_single(children) ? hm_children_single_rule(children) : NULL;
    old_arr = single ? NULL : children;
    rules = old_arr ? hm_get_child_rules(old_arr) : &single;
    old_count = old_arr ? old_arr->count : 1;

    for (int i = 0; i < old_count; i++) {
        if (READ_ONCE(rules[i]) == rule) {
            target_idx = i;
            break;
        }
    }
    if (target_idx == -1) return parent;

    rcu_read_lock();
    write_seqcount_begin(&dir_node->seq);
    if (old_count <= 2) {
        if (old_count == 2) {
            int remaining_idx = 1 - target_idx;
            rcu_assign_pointer(dir_node->children, hm_children_from_single(rules[remaining_idx]));
            dir_node->bloom_mask = 1ULL << (old_arr->hashes[remaining_idx] & 63);
        } else {
            rcu_assign_pointer(dir_node->children, NULL);
            dir_node->bloom_mask = 0;
        }
        write_seqcount_end(&dir_node->seq);
        if (old_count == 1 && !parent) {
            smp_mb();
            if (!rcu_access_pointer(dir_node->iop) && !rcu_access_pointer(dir_node->fop) &&
                cmpxchg(&dir_node->v_inode, NULL, (struct inode *)-1L) == NULL)
                call_rcu(&dir_node->rcu, hm_dir_rcu_free);
        }
        rcu_read_unlock();
        synchronize_srcu(&hybridmount_srcu);
        if (old_arr) kfree_rcu(old_arr, rcu);
        return parent;
    }

    if (target_idx < old_count - 1) {
        for (int i = target_idx; i < old_count - 1; i++) {
            WRITE_ONCE(old_arr->hashes[i], READ_ONCE(old_arr->hashes[i + 1]));
            WRITE_ONCE(rules[i], READ_ONCE(rules[i + 1]));
        }
    }

    WRITE_ONCE(old_arr->hashes[old_count - 1], 0);
    WRITE_ONCE(rules[old_count - 1], NULL);
    old_arr->count--;

    for (int i = 0; i < old_arr->count; i++) mask |= (1ULL << (old_arr->hashes[i] & 63));
    dir_node->bloom_mask = mask;
    write_seqcount_end(&dir_node->seq);
    rcu_read_unlock();
    return parent;
}

static void hm_detach_rule_locked(struct hybridmount_rule *rule, struct list_head *victims, bool prune);

static void hm_rollback_generated_topology_locked(struct hybridmount_rule *target_rule,
                                                   struct list_head *generated_rules,
                                                   struct list_head *victims)
{
    struct hybridmount_rule *rule;

    if (list_empty(&target_rule->list_node)) {
        if (target_rule->parent_dir)
            __hybridmount_delete_child_locked(target_rule);
        list_add_tail(&target_rule->list_node, victims);
    } else {
        hm_detach_rule_locked(target_rule, victims, false);
    }

    while (!list_empty(generated_rules)) {
        rule = list_last_entry(generated_rules, struct hybridmount_rule, topology_node);
        list_del_init(&rule->topology_node);
        if (list_empty(&rule->list_node)) {
            if (rule->parent_dir)
                __hybridmount_delete_child_locked(rule);
            list_add_tail(&rule->list_node, victims);
        } else {
            hm_detach_rule_locked(rule, victims, false);
        }
    }
}

static int hybridmount_generate_virtual_topology(struct hybridmount_rule *target_rule,
                                                 struct list_head *generated_rules,
                                                 struct list_head *victims)
{
    struct hybridmount_rule *current_rule = target_rule, *ex;
    char *v_path = hm_get_vpath(target_rule);
    int p_len = target_rule->v_len;
    struct hybridmount_dir_node *dir_node;
    struct hybridmount_rule *irule;
    struct path p_path;
    int i, p, err = 0;

    while (p_len > 1) {
        for (i = p_len - 1; i >= 0; i--)
            if (v_path[i] == '/') break; 

        int parent_len = (i == 0) ? 1 : i;
        const char *child_name = v_path + i + 1;
        size_t child_len = p_len - i - 1;

        if ((ex = hm_tree_search_path(parent_len, v_path))) {
            if (!(ex->flags & HM_FLAG_IS_DIR)) { err = -ENOTDIR; break; }
            if (unlikely(!(dir_node = ex->this_dir))) { err = -ENOMEM; break; }
            err = __hybridmount_inject_child_locked(dir_node, current_rule, child_name, child_len);
            break;
        }

        char orig_vpath = v_path[i];
        if (i > 0) v_path[i] = '\0';
        if ((p = kern_path((parent_len == 1) ? "/" : v_path, LOOKUP_FOLLOW, &p_path)), (v_path[i] = orig_vpath), (p == 0)) {
            struct inode *v_inode = d_backing_inode(p_path.dentry);
            struct hybridmount_dir_node *old_node = ({
                struct hm_iop *iop = hm_get_hm_iop(smp_load_acquire(&v_inode->i_op));
                struct hm_fop *fop = hm_get_hm_fop(smp_load_acquire(&v_inode->i_fop));
                (iop && iop->dir_node) ? iop->dir_node : (fop ? fop->dir_node : NULL);
            });

            if (unlikely(!(dir_node = old_node ?: __hybridmount_alloc_dir_node()))) {
                err = -ENOMEM;
            } else if ((err = __hybridmount_inject_child_locked(dir_node, current_rule, child_name, child_len))) {
                if (!old_node) kfree(dir_node);
            } else {
                hybridmount_hijack_dir_ops(dir_node, v_inode);
                hybridmount_hijack_superblock(p_path.dentry->d_sb);
                struct dentry *dentry = hm_hash_and_lookup(p_path.dentry, &(struct qstr)QSTR_INIT(child_name, child_len));
                if (dentry) { d_drop(dentry); dput(dentry); }
            }
            path_put(&p_path);
            break;
        }

        if (!(irule = kmalloc(sizeof(struct hybridmount_rule) + parent_len + 2, GFP_KERNEL))) { err = -ENOMEM; break; }
        memset(irule, 0, sizeof(*irule));
        INIT_LIST_HEAD(&irule->list_node);
        INIT_LIST_HEAD(&irule->topology_node);
        irule->v_len = parent_len;
        irule->v_hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, v_path, parent_len);
        irule->flags = HM_FLAG_IS_DIR | HM_FLAG_VIRTUAL_DIR;
        irule->v_ino = (unsigned long)irule->v_hash;
        memcpy(hm_get_vpath(irule), v_path, parent_len);
        hm_get_vpath(irule)[parent_len] = '\0';
        hm_get_rpath(irule)[0] = '\0';

        if (unlikely(!(dir_node = __hybridmount_alloc_dir_node()))) {
            kfree(irule); err = -ENOMEM;
            break;
        }

        if ((err = __hybridmount_inject_child_locked(dir_node, current_rule, child_name, child_len)) != 0) {
            kfree(dir_node); kfree(irule);
            break;
        }
        hm_dir_set_owner(dir_node, irule);
        irule->this_dir = dir_node;
        list_add(&irule->topology_node, generated_rules);
        current_rule = irule;
        p_len = i;
    }

    if (!err) {
        list_for_each_entry(irule, generated_rules, topology_node) {
            err = hm_tree_insert(irule);
            if (err)
                break;
        }
    }

    if (err)
        hm_rollback_generated_topology_locked(target_rule, generated_rules, victims);

    return err;
}

static void hm_detach_dir_node(struct hybridmount_dir_node *dir_node)
{
    struct hm_iop *iop;
    struct hm_fop *fop;
    if (!dir_node || hm_dir_is_virtual(dir_node)) return;

    rcu_read_lock();
    if ((iop = rcu_dereference(dir_node->iop))) WRITE_ONCE(iop->dir_node, NULL);
    if ((fop = rcu_dereference(dir_node->fop))) WRITE_ONCE(fop->dir_node, NULL);
    rcu_read_unlock();
}

static void hybridmount_prune_empty_virtual_dirs(struct hybridmount_dir_node *dir_node, struct list_head *victims)
{
    struct hybridmount_rule *owner;

    while (dir_node) {
        if (rcu_access_pointer(dir_node->children))
            break;

        if (!(owner = hm_dir_owner(dir_node)) || !(owner->flags & HM_FLAG_VIRTUAL_DIR))
            break;

        list_move(&owner->list_node, victims);
        hm_art_remove_leaf(&hybridmount_art_root, owner);
        dir_node = __hybridmount_delete_child_locked(owner);
        hm_debug("Pruned empty virtual directory: %s\n", hm_get_vpath(owner));
    }
}

/*** Rule Operations ***/

static struct hybridmount_rule *hm_alloc_rule(const char *v_path, const char *r_path, u16 v_len, u16 r_len, u32 flags, unsigned int target_uid)
{
    struct hybridmount_rule *rule;
    bool is_whiteout = (flags & HM_FLAG_WHITEOUT);
    bool is_opaque = (flags & HM_FLAG_OPAQUE);
    struct path v_path_struct;

    if (!v_path || (!r_path && !is_whiteout && !is_opaque)) return ERR_PTR(-EINVAL);
    while (v_len > 1 && v_path[v_len - 1] == '/') { v_len--; }
    if (!is_whiteout && !is_opaque) { while (r_len > 1 && r_path[r_len - 1] == '/') { r_len--; } }

    /* Whiteout and opaque rules carry no real path. */
    if (is_whiteout || is_opaque) r_len = 0;
    if (!(rule = kmalloc((sizeof(struct hybridmount_rule) + v_len + r_len + 2), GFP_KERNEL))) return ERR_PTR(-ENOMEM);

    memset(rule, 0, sizeof(*rule));
    INIT_LIST_HEAD(&rule->list_node);
    INIT_LIST_HEAD(&rule->topology_node);
    rule->v_hash = full_name_hash((const void *)(unsigned long)HYBRIDMOUNT_MAGIC_SIG, v_path, v_len);
    rule->flags = flags;
    /* An opaque directory replaces its whole subtree: it stays visible, hides every real
     * child and shows only the injected ones. That is virtual-dir behaviour without a
     * real path. */
    if (is_opaque) rule->flags |= HM_FLAG_IS_DIR | HM_FLAG_VIRTUAL_DIR;
    rule->v_len = v_len;
    rule->r_len = r_len;
    rule->target_uid = target_uid;
    memcpy(hm_get_vpath(rule), v_path, v_len);
    hm_get_vpath(rule)[v_len] = '\0';
    if (!is_whiteout && r_len) memcpy(hm_get_rpath(rule), r_path, r_len);
    hm_get_rpath(rule)[r_len] = '\0';

    if (!is_whiteout && !is_opaque) {
        struct inode *real_inode;

        /* Fail loudly instead of inserting a rule that can never match: without a real
         * path neither branch of resolve applies, so lookup always falls back to the
         * real file while userspace records the injection as successful. */
        if (kern_path(hm_get_rpath(rule), LOOKUP_FOLLOW, &rule->r_path) != 0) {
            kfree(rule);
            return ERR_PTR(-ENOENT);
        }
        real_inode = d_backing_inode(rule->r_path.dentry);
        if (likely(real_inode)) {
            real_inode->i_flags |= S_PRIVATE;
            if (S_ISDIR(real_inode->i_mode)) rule->flags |= HM_FLAG_IS_DIR;
        }
    }

    if (kern_path(hm_get_vpath(rule), LOOKUP_FOLLOW, &v_path_struct) == 0) {
        struct dentry *target_dentry = v_path_struct.dentry;
        struct inode *target_inode = d_backing_inode(target_dentry);
        rule->v_ino = target_inode ? target_inode->i_ino : (unsigned long)rule->v_hash;
        d_drop(target_dentry);
        path_put(&v_path_struct);
    } else {
         rule->v_ino = (unsigned long)rule->v_hash;
    }

    if (rule->flags & HM_FLAG_IS_DIR) {
        /* An opaque rule needs this_dir: without it the injected children are
         * unreachable while ADD_RULE still reports success. */
        rule->this_dir = __hybridmount_alloc_dir_node();
        if (unlikely(!rule->this_dir)) {
            /* VIRTUAL_DIR (opaque) rules carry no real path, as in hm_free_rule. */
            if (!(rule->flags & HM_FLAG_VIRTUAL_DIR) && rule->r_path.dentry) path_put(&rule->r_path);
            kfree(rule);
            return ERR_PTR(-ENOMEM);
        }
        hm_dir_set_owner(rule->this_dir, rule);
    }

    return rule;
}

static void hm_free_rule(struct hybridmount_rule *rule)
{
    if (rule->this_dir) {
        if (cmpxchg(&rule->this_dir->v_inode, NULL, (struct inode *)-1L) == NULL) {
            hm_detach_dir_node(rule->this_dir);
            call_rcu(&rule->this_dir->rcu, hm_dir_rcu_free);
        } else {
            hm_dir_set_owner(rule->this_dir, NULL);
        }
    }
    if (!(rule->flags & HM_FLAG_VIRTUAL_DIR) && rule->r_path.dentry)
        path_put(&rule->r_path);
    kfree(rule);
}

static void hm_detach_rule_locked(struct hybridmount_rule *rule, struct list_head *victims, bool prune)
{
    list_move(&rule->list_node, victims);
    hm_art_remove_leaf(&hybridmount_art_root, rule);
    if (rule->parent_dir) {
        struct hybridmount_dir_node *parent = __hybridmount_delete_child_locked(rule);
        if (prune) hybridmount_prune_empty_virtual_dirs(parent, victims);
    }
}

static int __hybridmount_add_rule(const char *v_path, const char *r_path, u16 v_len, u16 r_len, u32 flags,
                              unsigned int target_uid, struct list_head *r_victims)
{
    struct hybridmount_rule *rule, *existing;
    int err = 0;
    LIST_HEAD(generated_rules);

    if (IS_ERR((rule = hm_alloc_rule(v_path, r_path, v_len, r_len, flags, target_uid))))
        return PTR_ERR(rule);

    down_write(&hybridmount_rwsem);
    if ((existing = hm_tree_search_exact(rule->v_len, hm_get_vpath(rule), target_uid))) {
        if (existing->this_dir && (rule->flags & HM_FLAG_IS_DIR)) {
            if (rule->this_dir) call_rcu(&rule->this_dir->rcu, hm_dir_rcu_free);
            rule->this_dir = existing->this_dir;
            hm_dir_set_owner(rule->this_dir, rule);
            existing->this_dir = NULL;
        }
        hm_detach_rule_locked(existing, r_victims, false);
        hm_info("Shadowing existing rule for: %s\n", hm_get_vpath(rule));
    }

    if ((err = hybridmount_generate_virtual_topology(rule, &generated_rules, r_victims)) != 0) {
        up_write(&hybridmount_rwsem);
        return err;
    }

    if ((err = hm_tree_insert(rule)) != 0) {
        hm_rollback_generated_topology_locked(rule, &generated_rules, r_victims);
        up_write(&hybridmount_rwsem);
        return err;
    }
    while (!list_empty(&generated_rules)) {
        struct hybridmount_rule *generated = list_first_entry(
            &generated_rules, struct hybridmount_rule, topology_node);
        list_del_init(&generated->topology_node);
    }
    up_write(&hybridmount_rwsem);

    (flags & HM_FLAG_WHITEOUT) ? hm_info("Successfully added whiteout rule: %s\n", hm_get_vpath(rule))
    : hm_info("Successfully added injection rule: %s -> %s\n", hm_get_vpath(rule), hm_get_rpath(rule));
        
    return 0;
}

static void __hybridmount_del_rule(const char *v_path, u16 v_len, unsigned int target_uid, struct list_head *r_victims)
{
    while (v_len > 1 && v_path[v_len - 1] == '/') v_len--;
    struct hybridmount_rule *rule = hm_tree_search_exact(v_len, v_path, target_uid);
    if (rule) hm_detach_rule_locked(rule, r_victims, true);
}

static void __hybridmount_clear_all(int clear_flags)
{
    struct hybridmount_rule *rule, *n;
    LIST_HEAD(r_victims);

    if (clear_flags & HM_CLEAR_UIDS) {
        struct hm_uid_array *old;
        if ((old = rcu_dereference_protected(hybridmount_uids, lockdep_is_held(&hybridmount_rwsem)))) {
            RCU_INIT_POINTER(hybridmount_uids, NULL);
            kfree_rcu(old, rcu);
        }
    }
    if (clear_flags & HM_CLEAR_RULES) {
        void *old_art_root = hybridmount_art_root;
        struct rcu_head *retired = NULL, *head;

        hybridmount_art_root = NULL;
        list_splice_init(&hybridmount_rules_list, &r_victims);
        rcu_read_lock();
        list_for_each_entry(rule, &r_victims, list_node) {
            struct hybridmount_dir_node *dir = rule->parent_dir;
            void *children;

            if (!dir || !(children = rcu_dereference_protected(dir->children, lockdep_is_held(&hybridmount_rwsem))))
                continue;

            write_seqcount_begin(&dir->seq);
            rcu_assign_pointer(dir->children, NULL);
            dir->bloom_mask = 0;
            write_seqcount_end(&dir->seq);

            if (!hm_children_is_single(children)) {
                struct hybridmount_child_array *arr = children;
                arr->rcu.next = retired;
                retired = &arr->rcu;
            }
            if (!hm_dir_is_virtual(dir)) {
                smp_mb();
                if (!rcu_access_pointer(dir->iop) && !rcu_access_pointer(dir->fop) &&
                    cmpxchg(&dir->v_inode, NULL, (struct inode *)-1L) == NULL) {
                    dir->rcu.next = retired;
                    retired = &dir->rcu;
                }
            }
        }
        rcu_read_unlock();

        synchronize_rcu(); synchronize_srcu(&hybridmount_srcu);
        while ((head = retired)) {
            retired = head->next;
            kfree(head);
        }
        hm_art_free_tree(old_art_root);
        list_for_each_entry_safe(rule, n, &r_victims, list_node) hm_free_rule(rule);
    }

    if (clear_flags & HM_CLEAR_EXIT) hybridmount_restore_superblocks();
}

/*** Payload Communication API ***/

static int hm_process_payload(unsigned long user_addr)
{
    struct hm_payload *payload;
    struct page *page;
    unsigned long pg_off = offset_in_page(user_addr);
    char *buf_ptr, *buf_end;

    if (pg_off + sizeof(*payload) > PAGE_SIZE || get_user_pages_fast(user_addr, 1, FOLL_WRITE, &page) != 1) {
        /* Either the payload straddles a page boundary or it could not be pinned; the
         * offset separates the two, since a correctly aligned page always pins. */
        hm_err("payload page pin failed: addr=0x%lx, offset=%lu\n", user_addr, pg_off);
        return -EFAULT;
    }

    if ((payload = (void *)((char *)kmap(page) + pg_off))->magic != HYBRIDMOUNT_MAGIC_SIG) {
        /* The only symptom is -EFAULT, which a caller cannot tell apart from "no module
         * loaded". Log both magic values so a mismatched userspace build is obvious. */
        hm_err("payload magic mismatch: got 0x%llx, expected 0x%llx\n",
               (unsigned long long)payload->magic,
               (unsigned long long)HYBRIDMOUNT_MAGIC_SIG);
        kunmap(page);
        put_page(page);
        return -EFAULT;
    }

    payload->status = 0;
    /* ADD_RULE and DEL_RULE resume from the userspace cursor in arg1, so each validates it
     * before use: past data_size, (size_t)(buf_end - buf_ptr) wraps and the loop walks off
     * the payload. GET_LIST / GET_UIDS treat arg1 as a rule index, not a byte offset. */
    buf_ptr = payload->buffer;
    buf_end = payload->buffer + (payload->data_size > sizeof(payload->buffer) ? sizeof(payload->buffer) : payload->data_size);

    switch (payload->cmd) {
        case HM_CMD_GET_VERSION:
            memcpy(payload->buffer, HYBRIDMOUNT_VERSION, (payload->data_size = strlen(HYBRIDMOUNT_VERSION)));
            break;

        case HM_CMD_ADD_RULE: {
            LIST_HEAD(r_victims);
            int first_err = 0;
            u32 err_offset = 0;
            if (payload->data_size > sizeof(payload->buffer) || payload->arg1 > payload->data_size) {
                payload->status = -EINVAL;
                break;
            }
            buf_ptr += payload->arg1;
            while ((size_t)(buf_end - buf_ptr) >= sizeof(struct hm_rule_hdr)) {
                struct hm_rule_hdr *h = (void *)buf_ptr;
                u32 record_offset = (u32)(buf_ptr - payload->buffer);
                int err;
                buf_ptr += sizeof(*h);
                /* A truncated record must not pass silently: breaking here leaves status 0
                 * with the cursor mid-batch, contradicting the first-error contract. */
                if ((h->v_len + h->r_len) > (size_t)(buf_end - buf_ptr) || unlikely(h->v_len >= PATH_MAX || h->r_len >= PATH_MAX)) {
                    if (!first_err) { first_err = -EINVAL; err_offset = record_offset; }
                    break;
                }
                err = __hybridmount_add_rule(buf_ptr, buf_ptr + h->v_len, h->v_len, h->r_len, h->flags, h->uid, &r_victims);
                if (err && !first_err) { first_err = err; err_offset = record_offset; }
                buf_ptr += (size_t)(h->v_len + h->r_len);
            }
            if (!first_err && buf_ptr != buf_end) {
                first_err = -EINVAL;
                err_offset = (u32)(buf_ptr - payload->buffer);
            }
            /* Report the first failure and where it happened; a later success must not
             * mask it. On success arg1 stays the consumed cursor. */
            if (first_err) {
                /* Userspace only sees a status and an offset; the reason a rule was
                 * rejected (a real path that does not resolve, ENOMEM) is otherwise
                 * invisible on a device. */
                hm_warn("add_rule batch failed: status=%d, offset=%u, bytes=%u\n",
                        first_err, err_offset, payload->data_size);
                payload->status = first_err; payload->arg1 = err_offset;
            }
            else payload->arg1 = buf_ptr - payload->buffer;

            if (!list_empty(&r_victims)) {
                struct hybridmount_rule *rule, *tmp;
                synchronize_rcu(); synchronize_srcu(&hybridmount_srcu);
                list_for_each_entry_safe(rule, tmp, &r_victims, list_node) hm_free_rule(rule);
            }
            break;
        }

        case HM_CMD_DEL_RULE: {
            LIST_HEAD(r_victims);
            int first_err = 0;
            u32 err_offset = 0;
            if (payload->data_size > sizeof(payload->buffer) || payload->arg1 > payload->data_size) {
                payload->status = -EINVAL;
                break;
            }
            buf_ptr += payload->arg1;
            down_write(&hybridmount_rwsem);
            while ((size_t)(buf_end - buf_ptr) >= sizeof(struct hm_del_hdr)) {
                struct hm_del_hdr *h = (void *)buf_ptr;
                u32 record_offset = (u32)(buf_ptr - payload->buffer);
                buf_ptr += sizeof(*h);
                /* Same as ADD_RULE: a truncated record must not leave status 0, or the
                 * rollback side reads a partial delete as complete. */
                if (h->v_len > (size_t)(buf_end - buf_ptr)) {
                    if (!first_err) { first_err = -EINVAL; err_offset = record_offset; }
                    break;
                }
                __hybridmount_del_rule(buf_ptr, h->v_len, h->uid, &r_victims);
                buf_ptr += h->v_len;
            }
            if (!first_err && buf_ptr != buf_end) {
                first_err = -EINVAL;
                err_offset = (u32)(buf_ptr - payload->buffer);
            }
            up_write(&hybridmount_rwsem);
            /* As in ADD_RULE: report the first error and its offset, else the cursor. */
            if (first_err) {
                /* Reached only on a malformed or truncated record: the benign "nothing
                 * matched" result is reported as -ENOENT further down instead. */
                hm_warn("del_rule batch failed: status=%d, offset=%u, bytes=%u\n",
                        first_err, err_offset, payload->data_size);
                payload->status = first_err; payload->arg1 = err_offset;
            }
            else payload->arg1 = buf_ptr - payload->buffer;

            if (!list_empty(&r_victims)) {
                struct hybridmount_rule *rule, *tmp;
                synchronize_rcu(); synchronize_srcu(&hybridmount_srcu);
                list_for_each_entry_safe(rule, tmp, &r_victims, list_node) hm_free_rule(rule);
            } else if (!first_err) payload->status = -ENOENT;
            break;
        }

        case HM_CMD_ADD_UID:
            down_write(&hybridmount_rwsem);
            payload->status = hm_uid_add(payload->target_uid);
            up_write(&hybridmount_rwsem);
            break;

        case HM_CMD_DEL_UID:
            down_write(&hybridmount_rwsem);
            payload->status = hm_uid_del(payload->target_uid);
            up_write(&hybridmount_rwsem);
            break;

        case HM_CMD_CLEAR_ALL:
        case HM_CMD_CLEAR_UIDS:
        case HM_CMD_CLEAR_RULES:
            down_write(&hybridmount_rwsem);
            __hybridmount_clear_all((payload->cmd == HM_CMD_CLEAR_ALL) ? (HM_CLEAR_UIDS | HM_CLEAR_RULES) :
                                (payload->cmd == HM_CMD_CLEAR_UIDS) ? HM_CLEAR_UIDS : HM_CLEAR_RULES);
            up_write(&hybridmount_rwsem);
            break;

        case HM_CMD_GET_LIST: {
            int current_idx = 0;
            buf_ptr = payload->buffer;
            buf_end = payload->buffer + sizeof(payload->buffer);

            down_read(&hybridmount_rwsem);
            struct hybridmount_rule *r;
            list_for_each_entry(r, &hybridmount_rules_list, list_node) {
                if (current_idx++ < payload->arg1) continue;
                if ((sizeof(struct hm_rule_hdr) + r->v_len + r->r_len) > (size_t)(buf_end - buf_ptr)) { current_idx--; break; }

                *(struct hm_rule_hdr *)buf_ptr = (struct hm_rule_hdr){.flags = r->flags, .uid = r->target_uid, .v_len = r->v_len, .r_len = r->r_len};
                buf_ptr += sizeof(struct hm_rule_hdr);
                memcpy(buf_ptr, hm_get_vpath(r), r->v_len); buf_ptr += r->v_len;
                if (r->r_len > 0) { memcpy(buf_ptr, hm_get_rpath(r), r->r_len); buf_ptr += r->r_len; }
            }
            up_read(&hybridmount_rwsem);
            payload->data_size = buf_ptr - payload->buffer;
            payload->arg1 = current_idx;
            break;
        }

        case HM_CMD_GET_UIDS: {
            u32 *out = (u32 *)payload->buffer;
            int count = 0, start_idx = payload->arg1;
            struct hm_uid_array *arr;
            rcu_read_lock();
            if ((arr = rcu_dereference(hybridmount_uids))) {
                while (start_idx < READ_ONCE(arr->count) && count < (sizeof(payload->buffer) / sizeof(*out)))
                    out[count++] = arr->uids[start_idx++];
            }
            rcu_read_unlock();            
            payload->data_size = count * sizeof(*out);
            payload->arg1 = start_idx;
            break;
        }
    }

    kunmap(page);
    set_page_dirty_lock(page);
    put_page(page);
    return 0;
}

static int hm_key_preparse(struct key_preparsed_payload *prep)
{
    unsigned long user_addr = 0;
    if (!capable(CAP_SYS_ADMIN)) return -EPERM;
    if (prep->datalen == 8) user_addr = *(u64 *)prep->data;
    else if (prep->datalen == 4) user_addr = *(u32 *)prep->data;
    else return -EINVAL;
    if (user_addr) hm_process_payload(user_addr);
    return -ECANCELED;
}

static int dummy_key_instantiate(struct key *key, struct key_preparsed_payload *prep) { return -EINVAL; }
static void dummy_key_free_preparse(struct key_preparsed_payload *prep) { }

static struct key_type hm_key_type = {
    .name = "hybridmount",
    .preparse = hm_key_preparse,
    .free_preparse = dummy_key_free_preparse,
    .instantiate = dummy_key_instantiate,
};

static int __init hybridmount_init(void)
{
    int ret = register_key_type(&hm_key_type);
    if (ret) {
        hm_err("Failed to register key type (err: %d)\n", ret);
        return ret;
    }

    hm_info("Loaded successfully\n");
    return 0;
}

static void __exit hybridmount_exit(void)
{
    unregister_key_type(&hm_key_type);
    down_write(&hybridmount_rwsem);
    __hybridmount_clear_all(HM_CLEAR_UIDS | HM_CLEAR_RULES | HM_CLEAR_EXIT);
    up_write(&hybridmount_rwsem);
    rcu_barrier();
    hm_info("Unloaded successfully\n");
}

MODULE_LICENSE("GPL v2");
MODULE_VERSION(HYBRIDMOUNT_VERSION);
MODULE_AUTHOR("maxsteeel");
MODULE_DESCRIPTION("Hybrid Mount VFS Path Redirection Subsystem");

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
MODULE_IMPORT_NS("VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver");
MODULE_IMPORT_NS("ANDROID_GKI_VFS_EXPORT_ONLY");
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);
MODULE_IMPORT_NS(ANDROID_GKI_VFS_EXPORT_ONLY);
#endif

fs_initcall(hybridmount_init);
module_exit(hybridmount_exit);
