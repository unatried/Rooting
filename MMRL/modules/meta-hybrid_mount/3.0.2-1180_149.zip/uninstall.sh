#!/system/bin/sh
############################################
# mix-mount uninstall.sh
# Cleanup script for metamodule removal
############################################

rm -rf "/data/adb/meta-hybrid"

exit 0
