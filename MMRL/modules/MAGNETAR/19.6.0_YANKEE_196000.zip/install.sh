#   _____ __________ _____ ____ _____ _________
#  |     | _  |   __|   | |  __|_   _| _  | __ |
#  | | | |    |  |  | | | |  __| | | |    |   -|
#  |_|_|_|_|__|_____|_|___|____| |_| |_|__|_|__|
#                      by Kyliekyler © 2019-2025

#===========================================================================//
# GIVE PROPER CREDITS IF YOU USE THE PART OF IT IN YOUR WORK, THANKS!
#===========================================================================//

print_modname() { :; }

require_new_magisk() {
  abort "- PLEASE INSTALL MAGISK VERSION 26404 OR NEWER!"
}

require_new_ksu() {
  abort "- PLEASE INSTALL KERNELSU VERSION 11422 OR NEWER!"
}

require_new_ap() {
  abort "- PLEASE INSTALL APATCH VERSION 10472 OR NEWER!"
}

on_install() {
  $BOOTMODE || abort "- INSTALLATION FROM RECOVERY NOT SUPPORTED!"

  case "$ARCH" in
    arm|arm64) : ;;
    *) abort "- $(awk -v var="$ARCH" 'BEGIN{print toupper(var)}') NOT SUPPORTED!" ;;
  esac

  if [ -n "$APATCH" ] && [ "$APATCH_VER_CODE" -lt "10472" ]; then
    require_new_ap
  fi

  if [ -n "$KSU" ] && [ "$KSU_KERNEL_VER_CODE" -lt "11422" ]; then
    require_new_ksu
  fi
  
  if [ "$MAGISK_VER_CODE" -lt "26404" ] && [ -z "$KSU" ] && [ -z "$APATCH" ]; then
    require_new_magisk
  fi

  rm -rf $TMPDIR
  mkdir -p $TMPDIR
  chcon u:object_r:system_file:s0 $TMPDIR
  cd $TMPDIR || abort "- UNABLE TO CHANGE DIRECTORY"

  ensure_bb
  mount_partitions > /dev/null 2>&1
  boot_actions

  unzip -o "$ZIPFILE" module.prop -d $TMPDIR >&2
  [ ! -f $TMPDIR/module.prop ] && abort "- UNABLE TO EXTRACT ZIP FILE!"

  rm -rf $MODPATH

  MODID=$(grep_prop id $TMPDIR/module.prop)
  MODPATH=$MODULEROOT/$MODID

  mkdir -p $MODPATH

  unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/install 0 0 0755 0755

  [ -f "$MODPATH/install" ] && $MODPATH/install "$MODPATH"

  rm -rf \
    $MODPATH/LICENSE $MODPATH/install* \
    $MODPATH/*.json $MODPATH/*.md \
    $MODPATH/.git* $MODPATH/resources* \
    $MODPATH/dependencies* 2> /dev/null

  cd /
  rm -rf $TMPDIR

  exit 0
}
