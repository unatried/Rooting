## Changelog

- Added More Games to Database to Detect
- Fixed Battery Level Detection
- Fixed Charging State Detection for Android 12 Below
- Updated Dependencies
- Misc Improvements and Bug Fixes
