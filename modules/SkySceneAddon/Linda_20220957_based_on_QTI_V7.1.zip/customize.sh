##############
# Config Vars
##############

# Set this to true if you don't want to mount the system folder
SKIPMOUNT=false

# Set this to true if you want to debug the installation
DEBUG=true

###############
# Replace List
###############

# List all directories you want to directly replace in the system
# Construct your list in the following example format
REPLACE_EXAMPLE="/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework"

# Construct your own list here
REPLACE=""

##############
# Permissions
##############

set_permissions() {
  set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
}

#######
# Main
#######

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh

trap "kill -9 $capture_pid 2>/dev/null" EXIT

#########
# Commands
#########

rm_prop() {
	local prop
	for prop in "$@"; do
		resetprop -d "$prop" && {
			cat <<EOF

  X $prop deleted

EOF
			loger "$prop deleted"
		}
	done
}

approps() {
	local prop_file="$1" prop value

	set -f
	loger "Applying properties from $prop_file"
	resetprop -f "$prop_file"
	grep -v '^ *#' "$prop_file" | while IFS='=' read -r prop value; do
		cat <<EOF
  › $prop 
EOF
		if [ "$(getprop "$prop")" = "${value//=/ }" ]; then
			uprint "  » $value
"
		else
			uprint "  ! Failed
"
			loger e "Failed to apply $prop=$value"
		fi
	done
}

get_key_event() {
	local event_type="$1"
	local event_file="$TMPDIR/events"

	if [ -n "$capture_pid" ] && ! kill -0 $capture_pid; then
		unset capture_pid
	elif [ -z "$capture_pid" ]; then
		: >"$event_file"
		getevent -lq >$event_file &
		capture_pid=$!
	fi

	result=$(tail -n2 "$event_file" | grep "$event_type")
	until tail -n2 "$event_file" | awk '/UP/ { print $4 }' >/dev/null; do
		break
	done

	[ -n "$result" ] && sleep 0.25 && return 0 || return 1
}

#########
# Exec
#########

ui_print ""
ui_print "* SkyScene Add-on - Modern Memory Management"
ui_print "* https://github.com/WeirdMidas/SkySceneAddon"
ui_print "* Original Author: Matt Yang | Fork Author: Weird Midas"
ui_print "* Version: Linda (20220957) based on QTI V7.1"
ui_print "* SkyScene Add-on is a fork of Matt Yang's QTI Memory "
ui_print "* Optimization project. The fork was created with the intention"
ui_print "* of modernizing most, if not all, of the module's optimizations"
ui_print "* and scripts, in order to allow new users to use and enjoy the"
ui_print "* optimizations designed."
ui_print ""

install_A1Memory() {
	local applied=false
	cat <<EOF

- Welcome, dear users. If you are on Android 8
  or Android 14 or lower, you saw this message. 
  Here I will be providing a manual installation of 
  A1memory so you can enjoy the secondary
  optimizations in system memory management
  that this framework promises.
 
  Press VOLUME + to install A1memory
  Press VOLUME - to continue without A1Memory
EOF

	exec 3>&-
	set +x

	while true; do
		if get_key_event 'KEY_VOLUMEUP *DOWN'; then
			exec 3>&1
			set -x

            rm -rf /data/adb/modules*/Hc_memory
            magisk --install-module "$MODPATH"/modules/A1Memory.zip
			
			applied=true

			exec 3>&-
			set +x
			break
		elif get_key_event 'KEY_VOLUMEDOWN *DOWN'; then
		
		    echo "- skipping the A1Memory installation. "
		
			break
		fi
	done
	
	exec 3>&1
	set -x
	[ $applied ] || return 1
}

apply_QTI() {
	local totalmem_kb
	local android_version
	
    totalmem_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    android_version=$(getprop ro.build.version.release)

    if [ "$totalmem_kb" -le 2098652 ]; then
        cachedlimit="32"; backgroundlimit="24"
    elif [ "$totalmem_kb" -le 4197304 ]; then
        cachedlimit="64"; backgroundlimit="42"
    elif [ "$totalmem_kb" -le 6291456 ]; then
        cachedlimit="96"; backgroundlimit="72"
    else
        cachedlimit="128"; backgroundlimit="96"
    fi

	# Check if the device has android 9 or lower
	if [ "$android_version" -le 9 ]; then
		echo "
- Oh, your device is a Snapdragon! So, instead of modifying 
  the activity manager directly, we'll modify the Qualcomm 
  QTI framework directly. This will give us better memory
  management efficiency by providing something more  
  integrated with Qualcomm's drivers/hardware."
		cat <<EOF >>$MODPATH/system.prop
ro.vendor.qti.sys.fw.bg_apps_limit=$cachedlimit
ro.vendor.qti.sys.fw.bservice_limit=$backgroundlimit
EOF
    else
        echo "
- Your Snapdragon device is on a version above 10
  so we cannot modify the QTI framework via props.
  We will leave that to our post-fs-data.sh file. If you
  don't have the QTI framework, well, we will use the
  activity manager."
	fi
}

apply_ZygoteConfig() {
	local android_version
	android_version=$(getprop ro.build.version.release)
	# Check if the device has android 11
	if [ "$android_version" -ge 11 ]; then
		echo "
- Below you will find the Zygote optimizations 
  mentioned, designed to maintain the most up-to-date
  features on your device:

  1. Zygote preforking which basically maintains 
  empty copies of zygote that apps can use to
  start faster without have to go through the
  overhead of creating an zygote copy during 
  launch. You will notice faster app startup after 
  enabling it.
  
  2. Zygote Critical Window is a phase of Zygote
  where the application is critical. This function
  is used to signal this critical phase, speeding
  up Zygote's execution a bit."
		cat <<EOF >>$MODPATH/system.prop
persist.device_config.runtime_native.usap_pool_enabled=true
zygote.critical_window.minute=10
EOF
    else
        echo "
- Your device is too old to be compatible with 
  the zygote changes, sorry."
	fi
}

apply_cgroup_perapp() {
	local android_version
	android_version=$(getprop ro.build.version.release)
	# Check if the device has cgroup v2
	if grep -q "cgroup2" /proc/mounts; then
		echo "
- You have cgroup v2, so there is no need to
  manage memory by cgroup, the unified V2
  cgroup is much more efficient in this regard."
	# Check if the device is running Android 10 and has MEMCG
	elif [ "$android_version" -ge 10 ] && zcat /proc/config.gz 2>/dev/null | grep "^CONFIG_MEMCG=y"; then
		echo "
- You have cgroupv1 and cgroups memory support
  so it would be benefited to activate the per-APP
  to improve the precautionary of the LMKD due to
  the lack of unified solutions as cgroup V2."
		cat <<EOF >>$MODPATH/system.prop
ro.config.per_app_memcg=true
EOF
    else
        echo "
- Your device is too old to be compatible with 
  the per-app cgroup, sorry."
	fi
}

# Specific tuning functions
[ $(getprop ro.build.version.release) -le 14 ] && install_A1Memory
[ "$(getprop ro.hardware)" = "qcom" ] && apply_QTI
apply_ZygoteConfig
apply_cgroup_perapp
ui_print "* Applying the final cleaning, wait a moment, young man."
rm -rf "$MODPATH"/modules