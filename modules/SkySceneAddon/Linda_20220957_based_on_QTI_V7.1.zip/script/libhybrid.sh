#!/system/bin/sh
# Hybrid Swap Control Library
# https://github.com/unintellectual-hypothesis/pidmon
# Author: unintellectual-hypothesis
# Version: 20200323

# load lib
BASEDIR="$(dirname "$0")"
. $BASEDIR/pathinfo.sh

lz4hc_comp_eff=""
zstd_comp_eff=""
deflate_comp_eff=""
per_process_reclaim=""
swapfile_sz=""
prev_swapfile_sz=""
io_alg=""
swap_priority=""
PPR="/sys/module/process_reclaim/parameters"

swapfile_status() {
    local swap_info
    swap_info="$(cat /proc/swaps | grep "$SWAP_DIR/swapfile")"
    if [ "$swap_info" != "" ] && [ "$(read_cfg_value zram_size)" != "0" ]; then
        echo "Enabled. Size $(echo "$swap_info" | awk '{print $3}')kB."
    elif [ "$swap_info" != "" ] && [ "$(read_cfg_value zram_size)" == "0" ]; then
        echo "Enabled and without the help of ZRAM. Size $(echo "$swap_info" | awk '{print $3}')kB."
    else
        echo "Disabled by user."
    fi
}

setup_swapfile() {
    swapfile_sz="$(read_cfg_value swapfile_sz)"
    prev_swapfile_sz="$(ls -l "$SWAP_DIR"/swapfile | awk '{print $5}')"
    if [ -f "$SWAP_DIR"/swapfile ] && [ "$prev_swapfile_sz" == "$(gb_to_bytes "$swapfile_sz")" ]; then
        toybox swapon "$SWAP_DIR"/swapfile
    else
        dd if=/dev/zero of="$SWAP_DIR"/swapfile bs=1M count="$1"
        toybox mkswap "$SWAP_DIR"/swapfile
        toybox swapon "$SWAP_DIR"/swapfile
    fi
}

remove_swapfile() {
    [ -f "$SWAP_DIR/swapfile" ] && rm -f "$SWAP_DIR"/swapfile
}

configure_ppr() {
    if [ "$per_process_reclaim" = "true" ]; then
        lock_val "1" $PPR/enable_process_reclaim
        lock_val "90" $PPR/pressure_max
        lock_val "70" $PPR/pressure_min
        lock_val "801" $PPR/min_score_adj
        
        if [ -f $MM/lru_gen/enabled ]; then
            lock_val "10" $PPR/swap_eff_win
            lock_val "70" $PPR/swap_opt_eff
        else
            lock_val "5" $PPR/swap_eff_win
            lock_val "40" $PPR/swap_opt_eff
        fi

        if [ "$TMEM" -le 3145728 ]; then
            lock_val "128" $PPR/per_swap_size
        elif [ "$TMEM" -le 4197304 ]; then
            lock_val "256" $PPR/per_swap_size
        elif [ "$TMEM" -gt 4197304 ]; then
            lock_val "512" $PPR/per_swap_size
        fi
    else
        lock_val "0" $PPR/enable_process_reclaim
    fi
}

setup_hybrid_policy() {
    if [ "$swap_priority" = "0" ]; then
        mem_fallback swapon -p 100 $ZRAM_DEV
        mem_fallback swapon -p 100 $SWAP_DIR/swapfile
    elif [ "$swap_priority" = "-2" ]; then
        mem_fallback swapon -p 32758 $ZRAM_DEV
        mem_fallback swapon -p 1111 $SWAP_DIR/swapfile
    elif [ "$swap_priority" = "5" ]; then
        mem_fallback swapon -p 1111 $ZRAM_DEV
        mem_fallback swapon -p 32758 $SWAP_DIR/swapfile
    fi        
}

configure_custom_parameters() {
    [ -f $ZRAM/lz4hc_comp_level ] && lock_val "$1" $ZRAM/lz4hc_comp_level
    [ -f $ZRAM/zstd_comp_level ] && lock_val "$2" $ZRAM/zstd_comp_level
    [ -f $ZRAM/deflate_comp_level ] && lock_val "$3" $ZRAM/deflate_comp_level
    # normally the I/O algorithm depends heavily on the storage currently being used
    if [ -d "$SDA_Q" ]; then
        lock_val "$4" $SDA_Q/queue/scheduler
        # they typically use read_ahead_kb to mask latency and such
        lock_val "512" $SDA_Q/queue/read_ahead_kb
        # this change limits discard size for UFS(sda) to 128MB in order to avoid long IO latency
        lock_val "134217728" $SDA_Q/queue/discard_max_bytes
        # SSD storage does not benefit from add_random and rotational, as cited by several developers
        lock_val "0" $SDA_Q/queue/add_random
        lock_val "0" $SDA_Q/queue/rotational
        # In theory, SSDs benefit greatly from request merging
        lock_val "0" $SDA_Q/queue/nomerges
        # we prefer a fair balance between metadata and page cache
        lock_val "100" $VM/vfs_cache_pressure
        # UFS storage has shadow capability for successive writing
        lock_val "10" $VM/dirty_background_ratio
        lock_val "20" $VM/dirty_ratio
    else
        lock_val "$4" $MMC_Q/queue/scheduler
        # they typically use read_ahead_kb to mask latency and such
        # ... And EMMC has serious problems with subsequent requests
        lock_val "256" $MMC_Q/queue/read_ahead_kb
        lock_val "64" $MMC_Q/queue/nr_requests
        # SSD storage does not benefit from add_random and rotational, as cited by several developers
        lock_val "0" $MMC_Q/queue/add_random
        lock_val "0" $MMC_Q/queue/rotational
        # In theory, SSDs benefit greatly from request merging
        lock_val "0" $MMC_Q/queue/nomerges
        # we prefer to be more reliant on ZRAM rather than have a significant storage penalty
        lock_val "50" $VM/vfs_cache_pressure
        # EMMC storage does not have the privilege of waiting for writes
        lock_val "10" $VM/dirty_background_ratio
        lock_val "30" $VM/dirty_ratio
    fi
}

configure_hybrid_swapping() {
    if [ "$(read_cfg_value zram_size)" != "0" ] && [ "$(read_cfg_value swapfile_sz)" != "0" ]; then
        lock_val "3" $VM/page-cluster
        if [ -f $MM/lru_gen/enabled ]; then
            [ "$(mem_check_high_swappiness_support)" = "true" ] && lock_val "160" $VM/swappiness || lock_val "100" $VM/swappiness
        else
            lock_val "100" $VM/swappiness
        fi
        lock_val "1" $VM/swap_ratio_enable
        lock_val "70" $VM/swap_ratio
    elif [ "$(read_cfg_value zram_size)" = "0" ] && [ "$(read_cfg_value swapfile_sz)" != "0" ]; then
        lock_val "3" $VM/page-cluster
        lock_val "60" $VM/swappiness
        lock_val "0" $VM/swap_ratio_enable
        lock_val "100" $VM/swap_ratio
    elif [ "$(read_cfg_value zram_size)" != "0" ] && [ "$(read_cfg_value swapfile_sz)" = "0" ]; then
        lock_val "0" $VM/page-cluster
        if [ -f $MM/lru_gen/enabled ]; then
            [ "$(mem_check_high_swappiness_support)" = "true" ] && lock_val "160" $VM/swappiness || lock_val "100" $VM/swappiness
        else
            lock_val "100" $VM/swappiness
        fi
        lock_val "0" $VM/swap_ratio_enable
        lock_val "100" $VM/swap_ratio
    fi
}

io_get_available_alg() {

    # Linux 3.x may not have io algorithm tunable
    if [ -f "$SDA_Q/queue/scheduler" ]; then
        echo "$(cat $SDA_Q/queue/scheduler | sed "s/\[//g" | sed "s/\]//g")"
    else
        echo "$(cat $MMC_Q/queue/scheduler | sed "s/\[//g" | sed "s/\]//g")"
    fi
}

io_set_best_available_alg() {

    local ALGS=$(io_get_available_alg)

    if [ -f "$SDA_Q/queue/scheduler" ]; then
        if echo "$ALGS" | grep -q "none"; then
            echo "none"
        elif echo "$ALGS" | grep -q "mq-deadline"; then
            echo "mq-deadline"
        elif echo "$ALGS" | grep -q "noop"; then
            echo "noop"
        else
            echo "$ALGS" | awk '{print $1}'
        fi
    else
        if echo "$ALGS" | grep -q "bfq"; then
            echo "bfq"
        elif echo "$ALGS" | grep -q "cfq"; then
            echo "cfq"
        else
            echo "$ALGS" | awk '{print $1}'
        fi
    fi
}

change_recycling_threads_affinity() {
    if [ -d /sys/devices/system/cpu/cpufreq/policy0 ]; then
        if [ -d /sys/devices/system/cpu/cpufreq/policy4 ]; then
            if [ -d /sys/devices/system/cpu/cpufreq/policy7 ]; then
                change_task_affinity "kswapd" "7f"
                change_task_affinity "kcompactd" "7f"
            elif [ -d /sys/devices/system/cpu/cpufreq/policy6 ]; then
                change_task_affinity "kswapd" "3f"
                change_task_affinity "kcompactd" "3f"
            else
                change_task_affinity "kswapd" "ff"
                change_task_affinity "kcompactd" "ff"
            fi
        elif [ -d /sys/devices/system/cpu/cpufreq/policy6 ]; then
            change_task_affinity "kswapd" "3f"
            change_task_affinity "kcompactd" "3f"
        fi
    else
        change_task_affinity "kswapd" "7f"
        change_task_affinity "kcompactd" "7f"
    fi
}
