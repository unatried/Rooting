#!/system/bin/sh
# QTI memory optimization
# https://github.com/yc9559/qti-mem-opt
# Author: Matt Yang
# Version: v7.1 (20200328)

# Runonce after boot, to speed up the transition of power modes in powercfg

# load lib
BASEDIR="$(dirname "$0")"
. $BASEDIR/libcommon.sh
. $BASEDIR/libmem.sh
. $BASEDIR/libhybrid.sh
. $BASEDIR/libfscc.sh
. $BASEDIR/libadjshield.sh

TMEM="$(mem_get_total_byte)"
ZRAM_ALGS="$(mem_get_available_comp_alg)"
IO_ALGS="$(io_get_available_alg)"
[ "$ZRAM_ALGS" == "unsupported" ] && ZRAM_ALGS="<unsupported>"

zram_size=""
zram_alg=""
use_dedup=""
efk=""
wsf=""
cachedlimit=""
backgroundlimit=""
thrashingprev=""
ProacCompact=""
preferDefrag=""

config_reclaim_param() {
    # efk: higher to call kswapd earlier, reduces direct memory allocation
    # wsf: lower to reduce useless page swapping, large-size reclaiming induces more page re-faults
    # cachedlimit: maximum cached processes allowed (based on RAM tier) to prevent memory overcommit
    # backgroundlimit: maximum number of background processes that can run to avoid overcommit
    # thrashingprev: preference for having a minimum time to avoid thrashing on devices with low file cache
    # ProacCompact: It works with a preference for compaction and requires working in the background to achieve this
    # preferDefrag: preference is given to compacting memory to accommodate more processes in memory
    [ "$TMEM" -gt 8388608 ] && efk="204800" && wsf="40" && cachedlimit="128" && backgroundlimit="96" && thrashingprev="0" && ProacCompact="10" && preferDefrag="500"
    [ "$TMEM" -le 8388608 ] && efk="128000" && wsf="30" && cachedlimit="128" && backgroundlimit="96" && thrashingprev="0" && ProacCompact="10" && preferDefrag="500"
    [ "$TMEM" -le 6291456 ] && efk="102400" && wsf="25" && cachedlimit="96" && backgroundlimit="72" && thrashingprev="1000" && ProacCompact="25" && preferDefrag="750"
    [ "$TMEM" -le 4197304 ] && efk="76800" && wsf="20" && cachedlimit="64" && backgroundlimit="42" && thrashingprev="1000" && ProacCompact="25" && preferDefrag="750"
    [ "$TMEM" -le 3145728 ] && efk="51200" && wsf="15" && cachedlimit="64" && backgroundlimit="42" && thrashingprev="1000" && ProacCompact="25" && preferDefrag="650"
    [ "$TMEM" -le 2098652 ] && efk="25600" && wsf="10" && cachedlimit="32" && backgroundlimit="24" && thrashingprev="1000" && ProacCompact="25" && preferDefrag="650"
    [ "$TMEM" -le 1049326 ] && efk="19200" && wsf="10" && cachedlimit="32" && backgroundlimit="24" && thrashingprev="1000" && ProacCompact="25" && preferDefrag="650"
}

# $return:value(string)
calc_zram_default_size() {
    local val
    [ "$TMEM" -gt 8388608 ] && val="6"
    [ "$TMEM" -le 8388608 ] && val="4"
    [ "$TMEM" -le 6291456 ] && val="3"
    [ "$TMEM" -le 4197304 ] && val="2"
    [ "$TMEM" -le 3145728 ] && val="1.5"
    [ "$TMEM" -le 2098652 ] && val="1"
    [ "$TMEM" -le 1049326 ] && val="0.5"
    echo "$val"
}

# $return:value(string)
calc_swapfile_default_size() {
    local val
    [ "$TMEM" -gt 8388608 ] && val="0"
    [ "$TMEM" -le 8388608 ] && val="0"
    [ "$TMEM" -le 4197304 ] && val="0"
    [ "$TMEM" -le 2098652 ] && val="1"
    echo "$val"
}

config_zram() {
    # load size from file
    zram_size="$(read_cfg_value zram_size)"
    case "$zram_size" in
        0.0|0|0.5|1.0|1|1.2|1.5|2.0|2|2.1|2.2|2.5|3.0|3|4.0|4|5.0|5|6.0|6) ;;
        *) zram_size="$(calc_zram_default_size)" ;;
    esac

    # load algorithm from file, use zstd for high perf device and lz4 or lz4kd for lowmem as default
    zram_alg="$(read_cfg_value zram_alg)"
    [ "$zram_alg" == "" ] && zram_alg="$(algorithm_set_best_available_compabiity)"
    
    # load from file, enable in MGLRU and disable in LRU by default
    use_dedup="$(read_cfg_value use_dedup)"
    [ "$use_dedup" = "" ] && use_dedup="$(dedup_set_best_available_compabiity)"

    # load from file, but we will prefer the system standard
    lz4hc_comp_eff="$(read_cfg_value lz4hc_comp_eff)"
    [ "$lz4hc_comp_eff" = "" ] && lz4hc_comp_eff="$(cat $ZRAM/lz4hc_comp_level)"
    
    # load from file, but we will prefer the system standard
    zstd_comp_eff="$(read_cfg_value zstd_comp_eff)"
    [ "$zstd_comp_eff" = "" ] && zstd_comp_eff="$(cat $ZRAM/zstd_comp_level)"
    
    # load from file, but we will prefer the system standard
    deflate_comp_eff="$(read_cfg_value deflate_comp_eff)"
    [ "$deflate_comp_eff" = "" ] && deflate_comp_eff="$(cat $ZRAM/deflate_comp_level)"
    
    # load algorithm from file, use bfq for EMMC and the system default for UFS
    io_alg="$(read_cfg_value io_alg)"
    [ "$io_alg" = "" ] && io_alg="$(io_set_best_available_alg)"

    # ~3.1x compression ratio
    # higher disksize result in larger space-inefficient SwapCache
    case "$zram_size" in
        0.0|0)  mem_stop_zram ;;
        0.5)    mem_start_zram 512M 160M "$zram_alg" "$use_dedup" ;;
        1.0|1)  mem_start_zram 1024M 360M "$zram_alg" "$use_dedup" ;;
        1.2)    mem_start_zram 1248M 460M "$zram_alg" "$use_dedup" ;;
        1.5)    mem_start_zram 1536M 540M "$zram_alg" "$use_dedup" ;;
        2.0|2)  mem_start_zram 2048M 720M "$zram_alg" "$use_dedup" ;;
        2.1)  mem_start_zram 2180M 820M "$zram_alg" "$use_dedup" ;;
        2.2)  mem_start_zram 2304M 840M "$zram_alg" "$use_dedup" ;;
        2.5)    mem_start_zram 2560M 900M "$zram_alg" "$use_dedup" ;;
        3.0|3)  mem_start_zram 3072M 1080M "$zram_alg" "$use_dedup" ;;
        4.0|4)  mem_start_zram 4096M 1440M "$zram_alg" "$use_dedup" ;;
        5.0|5)  mem_start_zram 5120M 1800M "$zram_alg" "$use_dedup" ;;
        6.0|6)  mem_start_zram 6144M 2160M "$zram_alg" "$use_dedup" ;;
    esac
    
    # typically these additional swap/storage settings can be beneficial depending on the user's workload
    configure_custom_parameters "$lz4hc_comp_eff" "$zstd_comp_eff" "$deflate_comp_eff" "$io_alg"

    # target algorithm may be not supported
    zram_alg="$(mem_get_cur_comp_alg)"
}

setup_hybrid_swap() {
    # load from file, disabled by default
    per_process_reclaim="$(read_cfg_value per_process_reclaim)"
    [ "$per_process_reclaim" = "" ] && per_process_reclaim="false"
    
    # load from file, zram always first by default
    swap_priority="$(read_cfg_value swap_priority)"
    [ "$swap_priority" = "" ] && swap_priority="-2"
    
    # we expect an improvement of up to ~9-17% in effective memory
    # sometimes the PPR reclaim can be aggressive, but we shouldn't have too many negative effects
    configure_ppr

    swapfile_sz="$(read_cfg_value swapfile_sz)"
    case "$swapfile_sz" in
        0|0.5|1|1.5|2|2.5|3) ;;
        *) swapfile_sz="$(calc_swapfile_default_size)" ;;
    esac

    case "$swapfile_sz" in
        0)    remove_swapfile ;;
        0.5)  setup_swapfile 512 ;;
        1)    setup_swapfile 1024 ;;
        1.5)  setup_swapfile 1536 ;;
        2)    setup_swapfile 2048 ;;
        2.5)  setup_swapfile 2560 ;;
        3)    setup_swapfile 3072 ;;
    esac
    
    # we expect users to always choose ZRAM to act first, and Swapfile second
    setup_hybrid_policy && configure_hybrid_swapping
}

save_panel() {
    clear_panel
    write_panel ""
    write_panel "# SkyScene Add-on - MENU | For more information, see below"
    write_panel "# Fork Repo: https://github.com/WeirdMidas/SkySceneAddon"
    write_panel "# Original Author: Matt Yang | Fork Author: Weird Midas"
    write_panel "# Version: Linda (20220957) based on QTI V7.1"
    write_panel "# Last Log Update: $(date '+%Y-%m-%d %H:%M:%S')"
    write_panel "(The information displayed on the menu updates after the last execution; be advised.)"
    write_panel ""
    write_panel "[ZRAM Info]"
    write_panel "$(mem_zram_status)"
    write_panel ""
    write_panel "[Swapfile Info]"
    write_panel "$(swapfile_status)"
    write_panel ""
    write_panel "[Third-Party Info]"
    write_panel "FSCC is $(fscc_status)"
    write_panel "Adjshield is $(adjshield_status)"
    write_panel "- Config File Path: See $adjshield_cfg"
    write_panel "Activity Manager - $(mem_activitiy_manager)"
    write_panel ""
    write_panel "[Main Settings - Swap, Reclaim & Misc]"
    write_panel "# Available ZRAM size (GB): 0 / 0.5 / 1 / 1.2 / 1.5 / 2 / 2.1 / 2.2 / 2.5 / 3 / 4 / 5 / 6"
    write_panel "zram_size=$zram_size"
    write_panel "# Available ZRAM compression algorithm: $ZRAM_ALGS"
    write_panel "# Based on the capabilities of the SOC's little cores, the"
    write_panel "# recommended algorithm for you is: $(algorithm_pick_best_for_soc)"
    write_panel "# The algorithms that are not recommended are: lzo, lzo-rlt and deflate."
    write_panel "zram_alg=$zram_alg"
    if [ -f $ZRAM/lz4hc_comp_level ] || [ -f $ZRAM/zstd_comp_level ] || [ -f $ZRAM/deflate_comp_level ]; then
        write_panel ""
        write_panel "# ZRAM Trade-off. You can use this option to customize how much your algorithm"
        write_panel "# can compress between zstd, deflate, and lz4hc if your algorithm supports it. The"
        write_panel "# higher the number, the higher the compression ratio at the expense of speed, "
        write_panel "# and vice versa."
        [ -f $ZRAM/lz4hc_comp_level ] && write_panel "lz4hc_comp_eff=$lz4hc_comp_eff"
        [ -f $ZRAM/zstd_comp_level ] && write_panel "zstd_comp_eff=$zstd_comp_eff"
        [ -f $ZRAM/deflate_comp_level ] && write_panel "deflate_comp_eff=$deflate_comp_eff"
    fi
    if zcat /proc/config.gz 2>/dev/null | grep "^CONFIG_ZRAM_DEDUP=y"; then
        write_panel "# ZRAM dedup. Capable of saving between 5%-45% of memory "
        write_panel "# with 5-13% performance loss and higher power consumption. "
        write_panel "use_dedup=$use_dedup"
    fi
    write_panel "# Available Swapfile size (GB): 0 / 0.5 / 1 / 1.5 / 2 / 2.5 / 3"
    write_panel "swapfile_sz=$swapfile_sz"
    write_panel "# Swap Priority. Priority preference between ZRAM and Swapfile. "
    write_panel "# You can choose which one will have more preference for use. "
    write_panel "# 0) Normal priority, neither overrides the other "
    write_panel "# -2) ZRAM first, Swapfile after (The default and recommended)"
    write_panel "# 5) Swapfile first, ZRAM after "
    write_panel "swap_priority=$swap_priority"
    write_panel "# I/O Algorithm. You can choose another I/O algorithm if you feel comfortable. "
    write_panel "# Available I/O algorithms on your device: $IO_ALGS"
    write_panel "io_alg=$io_alg"
    if [ -d "/sys/module/process_reclaim" ]; then
        write_panel ""
        write_panel "# Per Process Reclaim. You can choose to use Per-Process Reclaim as a backup reclaim. "
        write_panel "# PPR will be used to assist the main management system if it shows signs of vulnerability"
        write_panel "# and needs help, minimizing the impact on the entire system and allowing PPR to work "
        write_panel "# alongside system memory management. It is recommended to use it only if you have "
        write_panel "# ZRAM or a Swapfile. Set to true to enable or false to disable. "
        write_panel "per_process_reclaim=$per_process_reclaim"
    fi
}

# we don't know when system will init ZRAM
mem_stop_zram
wait_until_login
mem_stop_zram

# wait until device has fully booted before applying the values below
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

# disable ZRAM after all inits load, to catch inits that reset ZRAM
mem_stop_zram

# Xiaomi K20pro need more time
sleep 15

config_zram
config_reclaim_param
setup_hybrid_swap

# set activity manager's max. cached app number for each device with different memories (instead of the default 32 (or even lower 24):
# https://gist.github.com/agnostic-apollo/dc7e47991c512755ff26bd2d31e72ca8
if [ $(getprop ro.build.version.release) -le 9 ] && [ "$(getprop ro.hardware)" = "qcom" ]; then
    setprop ro.vendor.qti.sys.fw.bg_apps_limit $cachedlimit
    setprop ro.vendor.qti.sys.fw.bservice_limit $backgroundlimit
elif [ -f "/system/vendor/etc/perf/perfconfigstore.xml" ] && [ $(getprop ro.build.version.release) -ge 10 ]; then
    # we will apply the changes to the QTI Framework via post-fs-data.sh
    echo "- we will apply the changes to the QTI Framework via post-fs-data.sh"
else
    [ $(getprop ro.build.version.release) -gt 9 ] && cmd device_config put activity_manager max_cached_processes "$cachedlimit" || settings put global activity_manager_constants max_cached_processes="$cachedlimit"
fi

# reduce the per-process limit of the mlock() family of system calls to
# 64 KB on account of a new CTS requirement
[ $(getprop ro.build.version.release) -ge 14 ] && setrlimit 8 65536 65536

# simple, this set below will be imposed on the MGLRU and LRU algorithms the standards recommended by Google and AOSP developers worldwide are:
if [ -f $MM/lru_gen/enabled ]; then
    [ -f $VM/direct_swappiness ] && lock_val "40" $VM/direct_swappiness
    lock_val "$wsf" $VM/watermark_scale_factor
    lock_val "$thrashingprev" $MM/lru_gen/min_ttl_ms
else
    lock_val "30" $VM/watermark_scale_factor
    lock_val "$efk" $VM/extra_free_kbytes
fi
# sometimes we need efficiency in compaction work, and we can't afford to suffer fragmentation
[ -f $VM/compaction_proactiveness ] && lock_val "$ProacCompact" $VM/compaction_proactiveness || lock_val "$preferDefrag" $VM/extfrag_threshold
lock_val "0" $VM/compact_unevictable_allowed
# if we have a lot of tasks running, and are OOMing often, then this overhead can add up
lock_val "0" $VM/oom_dump_tasks
# update /proc/stat information every 30 seconds, group with `cp_interval` and 'dirty_expire', improving efficiency and reducing jitter
lock_val "30" $VM/stat_interval
# disable oneplus kswapd modification
[ -f $VM/breath_period ] && lock_val "0" $VM/breath_period && lock_val "-1001" $VM/breath_priority
# it's better to have predictable memory management under pressure
lock_val "0" $VM/panic_on_oom
lock_val "1" $VM/oom_kill_allocating_task
[ "$(cat $VM/watermark_boost_factor)" -ge 0 ] && lock_val "0" $VM/watermark_boost_factor
# just to keep everything in order and synchronized, better for batching
lock_val "3000" $VM/dirty_expire_centisecs

# this can introduce aggressively excessive power consumption - specially when the system / your device is mostly idling
lock_val "3000" $USERDATA/cp_interval
# completely scoop out userspace gathering of IO statistics
lock_val "0" $USERDATA/iostat_enable
# the Android system is designed for interactivity; if apps take too long to recycle memory, it may be too late. That's why we prefer 50ms to the 5ms or 200ms that many custom kernels try to offer as a solution
lock_val "50" $USERDATA/gc_urgent_sleep_time
# decrease the lease-break grace period timer for processes that holds a file lease that the kernel have granted after notifying that one another process is as well waiting for opening the same file
lock_val "20" /proc/sys/fs/lease-break-time

# kernel reclaim threads run on more power-efficient cores
change_recycling_threads_affinity # should normally be enough for task allocation
change_task_nice "kswapd" "-2"
change_task_nice "oom_reaper" "-2"
change_task_nice "kcompactd" "-2"

# similar to Google's PinnerService in Google Pixel, Mlock(Unevictable) 150~250MB
fscc_add_obj "$SYS_FRAME/framework.jar"
fscc_add_obj "$SYS_FRAME/services.jar"
[ -f "/system/lib64/libsurfaceflinger.so" ] && fscc_add_obj "$SYS_LIB/libsurfaceflinger.so" || fscc_add_obj "$SYS_BIN/surfaceflinger"
fscc_add_apex_lib "core-oj.jar"
fscc_add_apex_lib "core-libart.jar"
# do not pin too many files on low memory devices
[ "$TMEM" -gt 2098652 ] && fscc_add_apk "com.android.systemui"
[ "$TMEM" -gt 2098652 ] && fscc_add_dex "com.android.systemui"
[ "$TMEM" -gt 2098652 ] && fscc_add_app_home
[ "$TMEM" -gt 4197304 ] && fscc_add_app_ime
[ "$TMEM" -gt 4197304 ] && fscc_add_app_cam
fscc_stop
fscc_start

# start adjshield
[ ! -f "$adjshield_cfg" ] && adjshield_create_default_cfg
adjshield_stop
adjshield_start

# save mode for automatic applying mode after reboot
save_panel

exit 0
