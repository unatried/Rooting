#!/system/bin/sh
# Linux memory tunning Library
# https://github.com/yc9559/
# Author: Matt Yang
# Version: 20200327

# include PATH
BASEDIR="$(dirname "$0")"
. $BASEDIR/pathinfo.sh

###############################
# Abbreviations
###############################

VM="/proc/sys/vm"
ZRAM="/sys/block/zram0"
ZRAM_DEV="/dev/block/zram0"
MM="/sys/kernel/mm"
SDA_Q="/sys/block/sda"
MMC_Q="/sys/block/mmcblk0"
USERDATA="/dev/sys/fs/by-name/userdata"

###############################
# ZRAM tool functions
###############################

# return: true/false
mem_has_zram_mod() {
    if [ -b "$ZRAM_DEV" ]; then
        echo "true"
    else
        echo "false"
    fi
}

# $1:binary $2:arg
mem_fallback() {
    # try binary provided by vendor toybox
    "/vendor/bin/$1" "$2"
    [ "$?" == "0" ] && return
    # try binary provided by system toybox
    "/system/bin/$1" "$2"
    # try binary provided by magisk busybox
    [ "$?" == "0" ] && return
    "$1" "$2"
}

mem_stop_zram() {
    # control swap if only the kernel support ZRAM, otherwise leave swap untouched
    [ "$(mem_has_zram_mod)" == "false" ] && return

    # swapoff all devices
    # swap devices may be not shown in blkid
    for dev in $(cat /proc/swaps | grep "^/" | awk '{print $1}'); do
        mem_fallback swapoff "$dev"
    done
}

# $1:disksize $2:mem_lim $3:alg $4:dedup
mem_start_zram() {
    # control swap if only the kernel support ZRAM, otherwise leave swap untouched
    [ "$(mem_has_zram_mod)" == "false" ] && return

    mem_stop_zram
    mutate "1" $ZRAM/reset
    [ -f $ZRAM/use_dedup ] && lock_val "$4" $ZRAM/use_dedup
    lock_val "$3" $ZRAM/comp_algorithm
    lock_val "$1" $ZRAM/disksize
    lock_val "$2" $ZRAM/mem_limit
    # holy crap, mkswap in busybox(32bit) cannot mkswap >= 4GB
    mem_fallback mkswap $ZRAM_DEV
    # swapon -p not supported by BusyBox v1.31.1-osm0sis
    # swapon $ZRAM_DEV -p 23333
    mem_fallback swapon $ZRAM_DEV
    # zram doesn't need much read ahead(random read)
    lock_val "0" $ZRAM/queue/read_ahead_kb
    [ -f $MM/swap/vma_ra_enabled ] && lock_val "true" $MM/swap/vma_ra_enabled
    # MGLRU gets along very well with android
    [ -f $MM/lru_gen/enabled ] && lock_val "Y" $MM/lru_gen/enabled
    # modern android doesn't benefit from hugepages anyway
    if [ -f $MM/transparent_hugepage/enabled ]; then
        lock_val "0" $MM/transparent_hugepage/khugepaged/defrag
        lock_val "never" $MM/transparent_hugepage/defrag
        lock_val "never" $MM/transparent_hugepage/enabled
        lock_val "never" $MM/transparent_hugepage/shmem_enabled
        lock_val "0" $MM/transparent_hugepage/use_zero_page
        lock_val "0" $MM/pgsize_migration/enabled
    fi
    # typically, lmkd has better accuracy regarding the system by actually recognizing the ZRAM thresholds
    if pgrep lmkd >/dev/null; then
        # algorithm check via comp
        alg=$(cat $ZRAM/comp_algorithm | grep -o '\[[^]]*\]' | tr -d '[]')
        # application of the swap_ratio value based on the algorithm
        if [ "$alg" = "zstd" ]; then
            cmd device_config put lmkd_native swap_compression_ratio 5
        elif [ "$alg" = "lz4hc" ]; then
            cmd device_config put lmkd_native swap_compression_ratio 4
        elif [ "$alg" = "lz4kd" ]; then
            cmd device_config put lmkd_native swap_compression_ratio 3
        elif [ "$alg" = "lz4" ]; then
            cmd device_config put lmkd_native swap_compression_ratio 3
        else
            cmd device_config put lmkd_native swap_compression_ratio 2
        fi
    else
        cmd device_config delete lmkd_native swap_compression_ratio
    fi
}

dedup_set_best_available_compabiity()  {

    # some devices for some reason remove dedup or do not enable compatibility with it
    if [ -f $MM/lru_gen/enabled ]; then
        echo "1"
    else
        echo "0"
    fi
}

mem_get_available_comp_alg() {
    if [ "$(mem_has_zram_mod)" == "false" ]; then
        echo "unsupported"
        return
    fi

    # Linux 3.x may not have comp_algorithm tunable
    if [ -f "$ZRAM/comp_algorithm" ]; then
        # "lz4 [lzo] deflate", remove '[' and ']'
        echo "$(cat $ZRAM/comp_algorithm | sed "s/\[//g" | sed "s/\]//g")"
    else
        # lzo is the default comp_algorithm since Linux 2.6
        echo "lzo"
    fi
}

mem_get_cur_comp_alg() {
    if [ "$(mem_has_zram_mod)" == "false" ]; then
        echo "unsupported"
        return
    fi

    local str
    # Linux 3.x may not have comp_algorithm tunable
    if [ -f "$ZRAM/comp_algorithm" ]; then
        # "lz4 [lzo] deflate"
        str="$(cat $ZRAM/comp_algorithm)"
        # remove "lz4 ["
        str="${str##*[}"
        # remove "] deflate"
        str="${str%%]*}"
        echo "$str"
    else
        # lzo is the default comp_algorithm since Linux 2.6
        echo "lzo"
    fi
}

algorithm_set_best_available_compabiity() {

    # get the frequency of CPU core 0 (usually a core in the little cluster)
    LITTLE_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
    LITTLE_MHZ=$((LITTLE_FREQ / 1000))

    # normalize supported algorithms (remove brackets)
    SUPPORTED=$(cat /sys/block/zram0/comp_algorithm | sed 's/\[//g; s/\]//g')

    # check if zstd or lz4kd exists in the kernel
    ZSTD_OK=$(echo "$SUPPORTED" | grep -c "zstd")
    LZ4KD_OK=$(echo "$SUPPORTED" | grep -c "lz4kd")

    # now the logic to work around it in the script
    if [ "$ZSTD_OK" -gt 0 ] && [ "$LITTLE_MHZ" -ge 2000 ]; then
        echo "zstd"
    elif [ "$LZ4KD_OK" -gt 0 ] && [ "$TMEM" -le 6291456 ]; then
        echo "lz4kd"
    else
        echo "lz4"
    fi
}

algorithm_pick_best_for_soc() {

    # get the frequency of the LITTLE core
    LITTLE_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
    LITTLE_MHZ=$((LITTLE_FREQ / 1000))

    # normalize supported algorithms (remove brackets)
    SUPPORTED=$(cat /sys/block/zram0/comp_algorithm | sed 's/\[//g; s/\]//g')

    # detect support
    ZSTD_OK=$(echo "$SUPPORTED" | grep -c "zstd")
    LZ4HC_OK=$(echo "$SUPPORTED" | grep -c "lz4hc")
    LZ4KD_OK=$(echo "$SUPPORTED" | grep -c "lz4kd")
    LZ4_OK=$(echo "$SUPPORTED" | grep -c "lz4")

    # logic
    if [ "$ZSTD_OK" -gt 0 ] && [ "$LITTLE_MHZ" -ge 2000 ]; then
        echo "zstd"
        return
    fi

    if [ "$LZ4HC_OK" -gt 0 ] && [ "$LITTLE_MHZ" -ge 1800 ]; then
        echo "lz4hc"
        return
    fi

    if [ "$LZ4KD_OK" -gt 0 ] && [ "$TMEM" -le 6291456 ]; then
        echo "lz4kd"
        return
    fi

    if [ "$LZ4_OK" -gt 0 ]; then
        echo "lz4"
        return
    fi

    # final fallback: pick the first listed algorithm
    for ALG in $SUPPORTED; do
        echo "$ALG"
        return
    done
}


mem_get_total_byte() {
    local mem_total_str
    mem_total_str="$(cat /proc/meminfo | grep MemTotal)"
    echo "${mem_total_str:16:8}"
}

# Convert GB to bytes
gb_to_bytes() {
    local gb=$1
    local bytes=$(echo "$gb * 1024 * 1024 * 1024" | bc)
    echo "$bytes"
}

mem_check_high_swappiness_support() {
    local target_value=200
    
    mutate "$target_value" $VM/swappiness 2>/dev/null

    local current_value=$(cat $VM/swappiness)

    if [ "$current_value" -eq "$target_value" ]; then
        echo "true"
    else
        echo "false"
    fi
}

# return:status
mem_zram_status() {
    # check whether the zram block device exists
    if [ "$(mem_has_zram_mod)" == "false" ]; then
        echo "Ignored. Unsupported by kernel."
        return
    fi

    local swap_info
    swap_info="$(cat /proc/swaps | grep "$ZRAM_DEV")"
    if [ "$swap_info" != "" ]; then
        echo "Enabled. Size $(echo "$swap_info" | awk '{print $3}')kB, using $(mem_get_cur_comp_alg)."
    else
        echo "Disabled by user."
    fi
}

# return:status
mem_activitiy_manager() {

    if [ "$TMEM" -le 2098652 ]; then
        cachedlimit="32"; backgroundlimit="24"
    elif [ "$TMEM" -le 4197304 ]; then
        cachedlimit="64"; backgroundlimit="42"
    elif [ "$TMEM" -le 6291456 ]; then
        cachedlimit="96"; backgroundlimit="72"
    else
        cachedlimit="128"; backgroundlimit="96"
    fi

    if [ $(getprop ro.build.version.release) -le 9 ] && [ "$(getprop ro.hardware)" = "qcom" ]; then
        echo "The device uses QTI Framework, and within its framework, the following are applied: $cachedlimit cached apps and $backgroundlimit background apps."
    elif [ -f "/system/vendor/etc/perf/perfconfigstore.xml" ] && [ $(getprop ro.build.version.release) -ge 10 ]; then
        echo "The device uses QTI Framework, and within its framework, the following are applied: $cachedlimit cached apps and $backgroundlimit background apps."
    else
        echo "The user is using Activity Manager, and with it, they have allowed up to $cachedlimit apps to be cached and half to run in the background."
    fi
}
