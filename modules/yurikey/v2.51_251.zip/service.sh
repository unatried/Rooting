MODPATH="${0%/*}"
. $MODPATH/common_func.sh

# Conditional sensitive properties

# Magisk Recovery Mode
resetprop_if_match ro.boot.mode recovery unknown
resetprop_if_match ro.bootmode recovery unknown
resetprop_if_match vendor.boot.mode recovery unknown
resetprop_if_match ro.boot.hwc CN GLOBAL
resetprop_if_match ro.boot.hwcountry China GLOBAL

# SELinux
resetprop_if_diff ro.boot.selinux enforcing
# use delete since it can be 0 or 1 for enforcing depending on OEM
if [ -n "$(resetprop ro.build.selinux)" ]; then
    resetprop --delete ro.build.selinux
fi
# use toybox to protect stat access time reading
if [ "$(toybox cat /sys/fs/selinux/enforce)" = "0" ]; then
    chmod 640 /sys/fs/selinux/enforce
    chmod 440 /sys/fs/selinux/policy
fi

# Conditional late sensitive properties

# must be set after boot_completed for various OEMs
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# SafetyNet/Play Integrity + OEM
# avoid bootloop on some Xiaomi devices
resetprop_if_diff ro.secureboot.lockstate locked
# avoid breaking Realme fingerprint scanners
resetprop_if_diff ro.boot.flash.locked 1
resetprop_if_diff ro.boot.realme.lockstate 1
# avoid breaking Oppo fingerprint scanners
resetprop_if_diff ro.boot.vbmeta.device_state locked
# avoid breaking OnePlus display modes/fingerprint scanners
resetprop_if_diff vendor.boot.verifiedbootstate green
# avoid breaking OnePlus/Oppo fingerprint scanners on OOS/ColorOS 12+
resetprop_if_diff ro.boot.verifiedbootstate green
resetprop_if_diff ro.boot.veritymode enforcing
resetprop_if_diff vendor.boot.vbmeta.device_state locked

# Other
resetprop_if_diff sys.oem_unlock_allowed 0
resetprop_if_diff init.svc.flash_recovery stopped

settings_delete_if_match global hidden_api_policy
settings_delete_if_match global hidden_api_policy_p_apps
settings_delete_if_match global hidden_api_policy_pre_p_apps
settings_delete_if_match global hidden_api_blacklist_exemptions
settings_delete_if_match global hidden_api_blacklist_exe

if [ -d "/data/local/tmp/shizuku" ]; then
	rm -rf /data/local/tmp/shizuku
	rm -rf /data/local/tmp/shizuku_starter
	pm uninstall -k --user 0 moe.shizuku.privileged.api
fi

#pm list packages | grep com.google.android.safetycore && pm uninstall com.google.android.safetycore