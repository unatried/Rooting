#!/system/bin/sh
# SpeedCool v2.3 - Safe Uninstallation (uninstall.sh)
# Author: Llucs

. ${0%/*}/../common/functions.sh

MODDIR=${0%/*}
CONFIG_DIR="$MODDIR/configs"
BACKUP_FILE="$CONFIG_DIR/backup/system_config_backup.conf"

log "📦 Starting SpeedCool uninstallation..."

# Step 1: Restore Original Settings
if [ -f "$BACKUP_FILE" ]; then
  log "🔁 Restoring original system settings..."

  while IFS== read -r key value; do
    case "$key" in
      cpu0_governor)
        path="/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"
        [ -w "$path" ] && echo "$value" > "$path" && log "✓ CPU0 governor restored: $value"
        ;;
      mmcblk0_scheduler)
        path="/sys/block/mmcblk0/queue/scheduler"
        [ -w "$path" ] && echo "$value" > "$path" && log "✓ mmcblk0 scheduler restored: $value"
        ;;
      *) log "ℹ️ Ignored: unknown key $key";;
    esac
  done < "$BACKUP_FILE"

else
  log "⚠️ No backup found. Applying safe default settings..."

  # Governor: schedutil
  for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -w "$gov" ] && echo "schedutil" > "$gov" && log "✓ Governor reset (fallback) at $gov"
  done

  # Thermal zones
  for therm in /sys/class/thermal/thermal_zone*/mode; do
    [ -w "$therm" ] && echo "enabled" > "$therm" && log "✓ Thermal zone enabled: $therm"
  done
fi

# Step 2: Remove module-generated files
log "🧹 Removing temporary files..."

rm -f /data/local/tmp/speedcool_chipset.tmp && log "✓ Removed speedcool_chipset.tmp"
rm -f "$MODDIR/boot_attempt_count" && log "✓ Removed boot attempt counter"
rm -rf "$MODDIR" && log "✓ Module directory removed: $MODDIR"

log "✅ SpeedCool successfully uninstalled. System restored!"
exit 0