#!/system/bin/sh

# SpeedCool v2.3 - post-fs-data.sh
# Executed very early in the boot process, before the system is fully mounted.
#
# Author: Llucs

# Include common helper functions
. ${0%/*}/common/functions.sh

# --- Root Check ---
[ "$(id -u)" -ne 0 ] && {
  log "ERROR: This script requires root to function properly." >&2
  exit 1
}

# --- Bootloop Prevention (Enhanced) ---
# The bootloop logic has been revised. Instead of disabling the module, we focus on
# ensuring that the settings are correctly applied and that the module
# does not cause instability. Magisk already has safety mechanisms for bootloops.
# Removed the auto-disable logic to avoid unwanted deactivations.

# Create required directories with verification and logging
mkdir -p /data/local/tmp || log "ERROR: Failed to create /data/local/tmp"
mkdir -p "$MODDIR/configs" || log "ERROR: Failed to create $MODDIR/configs"
mkdir -p "$MODDIR/configs/backup" || log "ERROR: Failed to create $MODDIR/configs/backup"

# --- Backup of Original System Settings ---
# This backup will be used to restore the original settings upon uninstallation.
BACKUP_FILE="$MODDIR/configs/backup/system_config_backup.conf"
if [ ! -f "$BACKUP_FILE" ]; then
    log "Creating backup of original system settings..."
    # Example: Backup of the current governor of CPU0
    if [ -f "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" ]; then
        echo "cpu0_governor=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor)" >> "$BACKUP_FILE"
    fi
    # Example: Backup of the I/O scheduler for mmcblk0
    if [ -f "/sys/block/mmcblk0/queue/scheduler" ]; then
        echo "mmcblk0_scheduler=$(cat /sys/block/mmcblk0/queue/scheduler)" >> "$BACKUP_FILE"
    fi
    # Add more important settings to back up here
    log "Backup of original settings completed at $BACKUP_FILE."
fi

# Detect chipset and store it using the unified function
CHIPSET=$(get_chipset)
echo "$CHIPSET" > /data/local/tmp/speedcool_chipset.tmp

# Ensure execution permissions for all scripts (0700) and config files (0600)
for file in config cooling learning_engine menu performance status anti-conflito; do
  [ -f "$MODDIR/scripts/${file}.sh" ] && chmod 0700 "$MODDIR/scripts/${file}.sh"
done

# Permissions for functions.sh
[ -f "$MODDIR/common/functions.sh" ] && chmod 0700 "$MODDIR/common/functions.sh"

# Permissions for configuration files
chmod 0600 "$MODDIR/settings.conf"
chmod 0600 "$MODDIR/configs/learning_params.conf" 2>/dev/null
chmod 0600 "$MODDIR/configs/conflitos_detectados.conf" 2>/dev/null
chmod 0600 "$MODDIR/configs/backup/system_config_backup.conf" 2>/dev/null

exit 0