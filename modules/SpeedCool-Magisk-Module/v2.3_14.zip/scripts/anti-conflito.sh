#!/system/bin/sh
# SpeedCool v2.3 - Anti-Conflict System
# Author: Llucs

. ${0%/*}/../common/functions.sh

CONFLICT_FILE="$MODDIR/configs/conflitos_detectados.conf"
touch "$CONFLICT_FILE"

MODULES_DIR="/data/adb/modules"
[ -d /data/adb/ksu/modules ] && MODULES_DIR="/data/adb/ksu/modules"

KNOWN_CONFLICTS="lspeed magnetar rickthermal frigus_thermal godspeed"

log "🛡️ Conflict Check Started at $(date '+%F %T')"

detect_conflicting_modules() {
  local found=""
  for dir in "$MODULES_DIR"/*; do
    [ ! -d "$dir" ] && continue
    name=$(basename "$dir")
    [ "$name" = "speedcool" ] && continue
    [ -f "$dir/disable" ] && continue
    for conf in $KNOWN_CONFLICTS; do
      echo "$name" | grep -qi "$conf" && found="$found $name"
    done
  done
  if [ -n "$found" ]; then
    log "⚠️ Conflicting modules found: $found"
    echo "modulos_conflitantes=$found" > "$CONFLICT_FILE"
    return 1
  fi
  return 0
}

detect_thermal_conflicts() {
  local detected=0
  for file in /sys/class/thermal/thermal_zone*/mode; do
    [ -f "$file" ] && [ "$(cat "$file")" != "enabled" ] && {
      log "⚠️ Disabled thermal zone: $file"
      detected=1
    }
  done
  return $detected
}

detect_governor_conflicts() {
  local detected=0
  for path in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$path" ] || continue
    gov=$(cat "$path")
    # Check for governors that are not common or expected for performance/powersave
    # This list can be expanded based on common Android kernel governors
    echo "$gov" | grep -qiE "schedutil|performance|powersave|interactive|ondemand|conservative|userspace|idle" || {
      log "⚠️ Suspicious governor detected: $gov at $path"
      detected=1
    }
  done
  return $detected
}

resolve_conflicts() {
  log "🔧 Attempting to safely resolve conflicts..."
  # Restore governors to schedutil or performance if schedutil is not available
  local default_gov="schedutil"
  if ! echo "$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null)" | grep -q "schedutil"; then
      default_gov="performance"
      log "Schedutil not available, using performance as the default governor for conflict resolution."
  fi

  for gov_path in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    if [ -w "$gov_path" ]; then
      echo "$default_gov" > "$gov_path" && log "✓ Governor restored: $gov_path to $default_gov"
    else
      log "❌ Could not restore governor at $gov_path (no write permission)."
    fi
  done

  # Reactivate thermal zones
  for therm_path in /sys/class/thermal/thermal_zone*/mode; do
    if [ -w "$therm_path" ]; then
      echo "enabled" > "$therm_path" && log "✓ Thermal zone reactivated: $therm_path"
    else
      log "❌ Could not reactivate thermal zone at $therm_path (no write permission)."
    fi
  done
}

# Execution
detect_conflicting_modules; modules_result=$?
detect_governor_conflicts; gov_result=$?
detect_thermal_conflicts; therm_result=$?

if [ "$modules_result" -ne 0 ] || [ "$gov_result" -ne 0 ] || [ "$therm_result" -ne 0 ]; then
  log "❗ Conflicts detected. Applying basic fixes..."
  resolve_conflicts
  # Add a flag to indicate that conflicts have been detected and resolved
  echo "conflito_detectado=1" >> "$MODDIR/configs/learning_params.conf"
else
  log "✅ No conflicts found. Safe environment for optimization."
  echo "conflito_detectado=0" >> "$MODDIR/configs/learning_params.conf"
fi

log "✔️ Anti-Conflict completed successfully."
exit 0