#!/system/bin/sh
# SpeedCool v2.3 - Interactive Colored Menu (menu.sh)
# Author: Llucs

. ${0%/*}/../common/functions.sh

CONFIG_SCRIPT="$MODDIR/scripts/config.sh"
STATUS_SCRIPT="$MODDIR/scripts/status.sh"
CONFIG_FILE="$MODDIR/configs/learning_params.conf"
CONFLICT_FILE="$MODDIR/configs/conflitos_detectados.conf"

mkdir -p "$MODDIR/configs"
touch "$CONFIG_FILE" "$CONFLICT_FILE"

# Check if tput is available (for Termux color support)
tput_available=false
command -v tput >/dev/null && tput_available=true

# Styles
reset_color()   { $tput_available && tput sgr0; }
bold()          { $tput_available && tput bold; }
blue()          { $tput_available && tput setaf 4; }
green()         { $tput_available && tput setaf 2; }
yellow()        { $tput_available && tput setaf 3; }
red()           { $tput_available && tput setaf 1; }

pause() {
  printf "\n"; read -r -p "Press Enter to continue..."
}

header() {
  clear
  blue; bold
  echo "╔══════════════════════════════════════════════════╗"
  echo "║         SpeedCool Interactive Menu v2.3          ║"
  echo "╚══════════════════════════════════════════════════╝"
  reset_color
}

show_current_mode() {
  MODE=$($CONFIG_SCRIPT get current_mode)
  [ -z "$MODE" ] && MODE="None (Default)"
  yellow; echo "Current mode: $MODE"; reset_color
}

select_mode() {
  while true; do
    header; show_current_mode
    echo ""
    echo " [1] Eco         → Energy saving and light cooling"
    echo " [2] Performance → Maximum performance"
    echo " [3] Learning    → Adaptive optimization"
    echo " [0] Back"
    printf "\nChoose an option: "; read -r choice
    case "$choice" in
      1) $CONFIG_SCRIPT set current_mode eco         && green; echo "✓ Eco mode activated"; reset_color; break ;;
      2) $CONFIG_SCRIPT set current_mode performance && green; echo "✓ Performance mode activated"; reset_color; break ;;
      3) $CONFIG_SCRIPT set current_mode learning    && green; echo "✓ Learning mode activated"; reset_color; break ;;
      0) break ;;
      *) red; echo "Invalid option!"; reset_color ;;
    esac
    pause
  done
}

show_status() {
  header
  echo -e "\nCurrent System Status:\n"
  $STATUS_SCRIPT
  pause
}

manage_conflicts() {
  header
  echo -e "\nConflict Manager:\n"
  CONFLITOS=$(grep "modulos_conflitantes" "$CONFLICT_FILE" 2>/dev/null | cut -d= -f2)
  if [ -n "$CONFLITOS" ]; then
    red; echo "⚠️  Conflicting modules detected: $CONFLITOS"; reset_color
    echo ""
    echo " [1] Disable conflicting modules (requires reboot)"
    echo " [0] Back"
    printf "\nChoose: "; read -r option
    if [ "$option" = "1" ]; then
      read -r -p "Are you sure you want to disable them? (y/N): " confirm
      if echo "$confirm" | grep -qi "^y"; then
        for module in $CONFLITOS; do
          for base in /data/adb/modules /data/adb/ksu/modules; do
            [ -d "$base/$module" ] && touch "$base/$module/disable" && green; echo "✓ $module disabled"; reset_color
          done
        done
        green; echo "✓ Conflicts resolved. Please reboot your device."; reset_color
      else
        yellow; echo "Operation cancelled by user."; reset_color
      fi
    fi
  else
    green; echo "No conflicts detected!"; reset_color
  fi
  pause
}

export_logs() {
  header
  LOG_SOURCE="$MODDIR/configs/speedcool.log"
  EXPORT_DIR="/sdcard/SpeedCool_logs"
  mkdir -p "$EXPORT_DIR"
  TARGET="$EXPORT_DIR/log_$(date +%Y%m%d_%H%M%S).log"

  if [ -f "$LOG_SOURCE" ]; then
    cp "$LOG_SOURCE" "$TARGET" && green; echo "✓ Log exported to $TARGET"; reset_color
  else
    red; echo "Log file not found at $LOG_SOURCE"; reset_color
  fi
  pause
}

check_updates() {
  header
  echo -e "\nChecking for updates...\n"
  local current=$(grep "^version=" "$MODDIR/module.prop" | cut -d= -f2)
  local latest=$(curl -s https://raw.githubusercontent.com/Llucs/SpeedCool-Magisk-Module/main/module.prop | grep "^version=" | cut -d= -f2)

  if [ -z "$latest" ]; then
    red; echo "Error: unable to check latest version (no connection?)"; reset_color
  elif [ "$current" = "$latest" ]; then
    green; echo "✔ You are using the latest version: $current"; reset_color
  else
    yellow; echo "⚠️ New version available: $latest (yours: $current)"; reset_color
    echo "🔗 Download at: https://github.com/Llucs/SpeedCool-Magisk-Module"
  fi
  pause
}

# Main menu
while true; do
  header
  show_current_mode
  echo ""
  echo " [1] Change Mode (Eco / Performance / Learning)"
  echo " [2] View System Status"
  echo " [3] Manage Conflicts"
  echo " [4] Export Logs"
  echo " [5] Check for Updates"
  echo " [0] Exit"
  printf "\nChoose an option: "; read -r option
  case "$option" in
    1) select_mode ;;
    2) show_status ;;
    3) manage_conflicts ;;
    4) export_logs ;;
    5) check_updates ;;
    0) echo -e "\nCome back soon ✨"; exit 0 ;;
    *) red; echo "Invalid option!"; reset_color; pause ;;
  esac
done