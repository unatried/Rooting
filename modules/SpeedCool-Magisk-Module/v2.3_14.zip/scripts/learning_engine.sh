#!/system/bin/sh
# SpeedCool v2.3 - Adaptive Learning Engine (learning_engine.sh)
# Author: Llucs

. ${0%/*}/../common/functions.sh

CONFIG_DIR="$MODDIR/configs"
CONFIG_FILE="$CONFIG_DIR/learning_params.conf"
LAST_CLEAN_FILE="$CONFIG_DIR/last_ram_clean.ts"
PROFILE_HISTORY="$CONFIG_DIR/profile_history.log"
COOLDOWN=180

mkdir -p "$CONFIG_DIR"
touch "$LAST_CLEAN_FILE" "$CONFIG_FILE"

load_user_config
[ -n "$DEBUG" ] && DEBUG="$DEBUG"

log "Starting SpeedCool Learning Engine v2.3"

get_time_hour() {
  date +%H
}

is_idle_period() {
  local hour=$(get_time_hour)
  [ "$hour" -ge 1 ] && [ "$hour" -le 6 ]
}

collect_metrics() {
  CPU_USAGE="0"
  RAM_TOTAL="0"
  RAM_FREE="0"
  RAM_USAGE_PCT="0"
  CPU_TEMP="N/A"
  BATTERY_LEVEL="N/A"
  BATTERY_STATUS="N/A"

  if command -v top >/dev/null; then
    CPU_USAGE=$(top -b -n 1 | grep -m1 "CPU" | awk '{print $2}' | tr -d '%')
  fi

  read -r RAM_TOTAL RAM_FREE <<<$(free | awk '/Mem:/ {print $2" "$4}')
  [ "$RAM_TOTAL" -gt 0 ] && RAM_USAGE_PCT=$(( (RAM_TOTAL - RAM_FREE) * 100 / RAM_TOTAL ))

  CPU_TEMP_RAW=$(cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | awk '{sum+=$1} END{print sum/NR}')
  [ -n "$CPU_TEMP_RAW" ] && CPU_TEMP=$((CPU_TEMP_RAW / 1000))

  BATTERY_LEVEL=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo "N/A")
  BATTERY_STATUS=$(cat /sys/class/power_supply/battery/status 2>/dev/null || echo "N/A")
}

decide_profile() {
  if [ "$CONFLICT_DETECTED" -eq 1 ]; then
    OPTIMIZATION_PROFILE="balanced"
    log "Conflicts detected. Using safe profile: balanced"
    return
  fi

  if is_idle_period; then
    OPTIMIZATION_PROFILE="eco"
    log "Nighttime idle period detected. Switching to Eco mode"
    return
  fi

  if [ "$CPU_USAGE" -gt 70 ] || [ "$RAM_USAGE_PCT" -gt 85 ]; then
    OPTIMIZATION_PROFILE="performance"
  elif [ "$CPU_USAGE" -gt 35 ] || [ "$RAM_USAGE_PCT" -gt 60 ]; then
    OPTIMIZATION_PROFILE="balanced"
  else
    OPTIMIZATION_PROFILE="eco"
  fi
}

should_clean_ram() {
  NOW=$(date +%s)
  LAST=$(cat "$LAST_CLEAN_FILE" 2>/dev/null || echo 0)
  ELAPSED=$((NOW - LAST))
  CLEAN=0

  [ "$ELAPSED" -lt "$COOLDOWN" ] && return

  case "$OPTIMIZATION_PROFILE" in
    performance) [ "$RAM_USAGE_PCT" -gt 75 ] && CLEAN=1 ;;
    balanced)    [ "$RAM_USAGE_PCT" -gt 85 ] && CLEAN=1 ;;
    eco)         [ "$RAM_USAGE_PCT" -gt 92 ] && CLEAN=1 ;;
  esac
}

clean_ram() {
  sync
  echo 1 > /proc/sys/vm/drop_caches 2>/dev/null && date +%s > "$LAST_CLEAN_FILE"
  log "RAM cleaned: current usage = $RAM_USAGE_PCT%"
}

log_metrics() {
  log "CPU: ${CPU_USAGE}% | RAM: ${RAM_USAGE_PCT}% | Temp: ${CPU_TEMP}ºC | Battery: ${BATTERY_LEVEL}% ($BATTERY_STATUS)"
  echo "$(date +%F\ %T) | Profile applied: $OPTIMIZATION_PROFILE" >> "$PROFILE_HISTORY"
}

save_state() {
  {
    echo "optimization_profile=$OPTIMIZATION_PROFILE"
    echo "cpu_usage=$CPU_USAGE"
    echo "cpu_temp=$CPU_TEMP"
    echo "ram_usage_percent=$RAM_USAGE_PCT"
    echo "battery_level=$BATTERY_LEVEL"
    echo "battery_status=$BATTERY_STATUS"
  } > "$CONFIG_FILE"
}

# Main loop
while true; do
  [ -f "/sys/power/state" ] && [ "$(cat /sys/power/state)" = "mem" ] && {
    log "learning_engine paused (suspend mode)"
    sleep 300
    continue
  }

  CONFLICT_DETECTED=0
  check_magisk_modules || CONFLICT_DETECTED=1
  check_cpu_governors || CONFLICT_DETECTED=1
  check_thermal_configs || CONFLICT_DETECTED=1

  [ "$CONFLICT_DETECTED" -eq 1 ] && resolve_conflicts

  collect_metrics
  decide_profile
  save_state
  log_metrics

  should_clean_ram && clean_ram

  sleep 300
done