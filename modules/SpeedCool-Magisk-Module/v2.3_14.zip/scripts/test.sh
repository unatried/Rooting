#!/system/bin/sh

# SpeedCool v2.3 - Test Script (test.sh)
# This script simulates usage scenarios to verify the stability and behavior of the SpeedCool module.
#
# Author: Llucs

# --- Variables and Paths ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_SCRIPT="$SCRIPT_DIR/config.sh"
STATUS_SCRIPT="$SCRIPT_DIR/status.sh"

# Include common functions
. "$SCRIPT_DIR/../common/functions.sh"

log "Starting SpeedCool v2.3 tests..."

# --- Scenario 1: High CPU Load ---
echo "\n=== High CPU Load Test ==="
log "Simulating high CPU load..."
# Activate performance mode
$CONFIG_SCRIPT set current_mode performance

# Simulate CPU load for 30 seconds
(for i in $(seq 1 $(nproc)); do while :; do :; done & done) & PID_LOAD=$!
sleep 30
kill $PID_LOAD 2>/dev/null
killall : 2>/dev/null

log "Checking status after high load..."
$STATUS_SCRIPT

# --- Scenario 2: Low Battery (Simulation) ---
echo "\n=== Low Battery Test ==="
log "Simulating low battery and Eco mode..."
# Activate eco mode
$CONFIG_SCRIPT set current_mode eco

# Simulate low battery (does not affect actual hardware, only internal logic)
# There's no direct shell method to simulate this for module reaction.
# Low battery logic is handled by learning_engine.sh based on `battery_level`.
# For a real test, a device with low battery would be required.

log "Checking status after low battery simulation..."
$STATUS_SCRIPT

# --- Scenario 3: Mode Switching ---
echo "\n=== Mode Switching Test ==="
log "Switching between Eco and Performance modes..."

$CONFIG_SCRIPT set current_mode eco
log "Current mode: Eco"
sleep 10

$CONFIG_SCRIPT set current_mode performance
log "Current mode: Performance"
sleep 10

$CONFIG_SCRIPT set current_mode learning
log "Current mode: Learning"
sleep 10

log "Checking status after mode switching..."
$STATUS_SCRIPT

# --- Scenario 4: Conflict Detection (Simulation) ---
echo "\n=== Conflict Detection Test ==="
log "Simulating conflict detection..."
# Create a simulated conflict file
mkdir -p "$SCRIPT_DIR/../configs"
echo "modulos_conflitantes=modulo_conflitante_simulado" > "$SCRIPT_DIR/../configs/conflitos_detectados.conf"

# Force learning_engine to re-evaluate (in a real environment, it does this periodically)
killall -HUP learning_engine.sh 2>/dev/null
sleep 5

log "Checking status after conflict simulation..."
$STATUS_SCRIPT

# Clean up simulated conflict
rm -f "$SCRIPT_DIR/../configs/conflitos_detectados.conf"

log "SpeedCool v2.3 tests completed. Check the log for details."

exit 0