#!/system/bin/sh
# SpeedCool - cooling.sh
# Thermal monitoring and adaptive cooling application

# Simple log function
log() {
  echo "[SpeedCool][Cooling] $1"
}

# Function for safe temperature reading
read_temp() {
  local sensor_path=$1
  [ -r "$sensor_path" ] || return 1
  local temp=$(cat "$sensor_path" 2>/dev/null)
  [ "$temp" -gt 1000 ] 2>/dev/null && echo $temp || return 1
}

# Detect valid thermal sensors
detect_sensors() {
  local valid_sensors=()
  for sensor in /sys/class/thermal/thermal_zone*/temp /sys/class/power_supply/*/temp /sys/class/hwmon/*/temp*_input; do
    value=$(read_temp "$sensor")
    [ -n "$value" ] && valid_sensors+=("$sensor")
  done

  # Fallback if no valid sensor is found
  [ "${#valid_sensors[@]}" -eq 0 ] && valid_sensors+=("/sys/class/thermal/thermal_zone0/temp")

  echo "${valid_sensors[@]}"
}

# Main function
cooling_loop() {
  log "Starting adaptive cooling..."

  local sensors=($(detect_sensors))
  local temp_sum=0
  local valid_count=0

  for sensor_path in "${sensors[@]}"; do
    temp=$(read_temp "$sensor_path")
    [ -n "$temp" ] && {
      temp_sum=$((temp_sum + temp))
      valid_count=$((valid_count + 1))
    }
  done

  [ "$valid_count" -eq 0 ] && log "No valid reading found." && exit 1

  avg_temp=$((temp_sum / valid_count))
  temp_celsius=$((avg_temp / 1000))

  log "Average temperature: ${temp_celsius}ºC"

  # Simple conditional actions
  if [ "$temp_celsius" -ge 45 ]; then
    log "Critical temperature detected. Applying maximum cooling mode."
    # Example: limit frequency, apply conservative governor, etc.
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
  elif [ "$temp_celsius" -ge 38 ]; then
    log "Moderate temperature. Applying balanced mode."
    echo "ondemand" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
  else
    log "Normal temperature. No action needed."
  fi
}

cooling_loop
exit 0