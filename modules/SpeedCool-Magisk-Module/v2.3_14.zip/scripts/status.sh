#!/system/bin/sh
# SpeedCool v2.3 - Universal Status Report
MODDIR="$(dirname "$(dirname "$0")")"
. "$MODDIR/common/functions.sh"

CONFIG_FILE="$MODDIR/configs/learning_params.conf"
CONFLICT_FILE="$MODDIR/configs/conflitos_detectados.conf"

tput_avail=false
command -v tput >/dev/null && tput_avail=true

reset() { $tput_avail && tput sgr0; }
bold() { $tput_avail && tput bold; }
blue() { $tput_avail && tput setaf 4; }
green() { $tput_avail && tput setaf 2; }
yellow() { $tput_avail && tput setaf 3; }
red() { $tput_avail && tput setaf 1; }

section() { echo ""; blue; bold; echo "= $1 ="; reset; }
to_mb() { echo $(( $1 / 1024 ))MB; }

# ---------------------------
# CPU
# ---------------------------
show_cpu() {
  section "CPU"
  CORES=$(grep -c ^processor /proc/cpuinfo 2>/dev/null || echo "Unknown")
  USAGE=$(grep "cpu_usage=" "$CONFIG_FILE" | cut -d= -f2 || echo "N/A")
  echo "Cores: $CORES | Usage: $USAGE%"
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    idx=$(basename "$cpu" | cut -c4-)
    FREQ=$(cat "$cpu/cpufreq/scaling_cur_freq" 2>/dev/null || echo 0)
    GOV=$(cat "$cpu/cpufreq/scaling_governor" 2>/dev/null || echo "N/A")
    [ -z "$FREQ" ] && FREQ=0
    [ -z "$GOV" ] && GOV="N/A"
    echo " • CPU$idx: $((FREQ/1000))MHz ($GOV)"
  done
}

# ---------------------------
# RAM
# ---------------------------
show_ram() {
  section "RAM"
  USAGE=$(grep "ram_usage_percent=" "$CONFIG_FILE" | cut -d= -f2 || echo "N/A")
  echo "RAM Usage: $USAGE%"
  awk '/MemTotal|MemAvailable/ {print $1,$2}' /proc/meminfo 2>/dev/null | while read key val; do
    echo " • $key: $(to_mb ${val:-0})"
  done
}

# ---------------------------
# Temperature
# ---------------------------
show_temp() {
  section "Temperature"
  
  # 1) From config file
  TEMP=$(grep "cpu_temp=" "$CONFIG_FILE" | cut -d= -f2 2>/dev/null)
  
  # 2) Thermal zones
  [ -z "$TEMP" ] && TEMP=$(cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | head -n1)
  
  # 3) dumpsys battery
  [ -z "$TEMP" ] && TEMP=$(dumpsys battery 2>/dev/null | grep temperature | awk '{print $2}')
  
  # 4) fallback
  [ -z "$TEMP" ] && TEMP="N/A"

  echo "Average CPU Temp: $TEMP°C"

  # List all zones
  for zone in /sys/class/thermal/thermal_zone*/temp; do
    [ ! -f "$zone" ] && continue
    RAW=$(cat "$zone" 2>/dev/null || echo "")
    [ -z "$RAW" ] && continue
    TYPE=$(cat "${zone%/*}/type" 2>/dev/null || echo "Unknown")
    [ "$RAW" -lt 1000 ] && RAW=$((RAW*1000))
    echo " • $TYPE: $((RAW/1000))°C"
  done
}

# ---------------------------
# GPU (universal support)
# ---------------------------
show_gpu() {
  section "GPU"

  # 1) KGSL (Snapdragon)
  GOV=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null)
  FREQ=$(cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null)

  # 2) Exynos / MediaTek fallback
  [ -z "$GOV" ] && GOV=$(cat /sys/class/devfreq/*gpu*/governor 2>/dev/null | head -n1)
  [ -z "$FREQ" ] && FREQ=$(cat /sys/class/devfreq/*gpu*/cur_freq 2>/dev/null | head -n1)

  # 3) general fallback
  [ -z "$GOV" ] && GOV="N/A"
  [ -z "$FREQ" ] && FREQ=0

  echo "Frequency: $((FREQ/1000000)) MHz | Governor: $GOV"
}

# ---------------------------
# Battery
# ---------------------------
show_battery() {
  section "Battery"

  LEVEL=$(grep "battery_level=" "$CONFIG_FILE" | cut -d= -f2 || echo "")
  STATUS=$(grep "battery_status=" "$CONFIG_FILE" | cut -d= -f2 || echo "")

  [ -z "$LEVEL" ] && LEVEL=$(dumpsys battery 2>/dev/null | grep level | awk '{print $2}' || echo "N/A")
  [ -z "$STATUS" ] && STATUS=$(dumpsys battery 2>/dev/null | grep status | awk '{print $2}' || echo "N/A")

  echo "Level: ${LEVEL:-N/A}% | Status: ${STATUS:-N/A}"
}

# ---------------------------
# Active Mode
# ---------------------------
show_mode() {
  section "Active Mode"
  MODE=$(grep "optimization_profile=" "$CONFIG_FILE" | cut -d= -f2 || echo "Unknown")
  echo "Applied Profile: $MODE"
}

# ---------------------------
# Conflicts
# ---------------------------
show_conflicts() {
  section "Conflicts"
  FOUND=$(grep "modulos_conflitantes" "$CONFLICT_FILE" 2>/dev/null | cut -d= -f2)
  if [ -z "$FOUND" ]; then green; echo "✓ No conflicts detected."; reset
  else red; echo "⚠️ Active conflicts: $FOUND"; reset
  fi
}

# ---------------------------
# Main Execution
# ---------------------------
show_mode
show_cpu
show_gpu
show_ram
show_temp
show_battery
show_conflicts
reset
exit 0