#!/system/bin/sh

# SpeedCool v2.3 - Configuration Manager (config.sh)
# Handles reading and writing in learning_params.conf
#
# Author: Llucs

# --- Variables and Paths ---
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_DIR="$SCRIPT_DIR/../configs"
CONFIG_FILE="$CONFIG_DIR/learning_params.conf"

# Include common functions
. "$SCRIPT_DIR/../common/functions.sh"

# Load user configurations
load_user_config

# Override DEBUG if defined in user_config.prop
if [ -n "$DEBUG" ]; then
    DEBUG="$DEBUG"
fi

# Ensure the configuration file exists
mkdir -p "$CONFIG_DIR" || log "ERROR: Could not create configuration directory: $CONFIG_DIR."
touch "$CONFIG_FILE" || log "ERROR: Could not create configuration file: $CONFIG_FILE."

# --- Functions ---

# Function to get a value
# Usage: config.sh get <key>
get_value() {
    local key="$1"
    if [ -f "$CONFIG_FILE" ]; then
        grep "^${key}=" "$CONFIG_FILE" | cut -d'=' -f2-
    fi
}

# Function to set a value
# Usage: config.sh set <key> <value>
set_value() {
    local key="$1"
    local value="$2"
    local temp_file="${CONFIG_FILE}.tmp"

    # Create the file if it does not exist
    touch "$CONFIG_FILE"

    # Remove the old key (if any) and add the new one
    grep -v "^${key}=" "$CONFIG_FILE" > "$temp_file"
    echo "${key}=${value}" >> "$temp_file"

    # Replace the original file with the temporary one
    mv "$temp_file" "$CONFIG_FILE"
    chmod 644 "$CONFIG_FILE"
    log "Configuration updated: $key=$value"
}

# --- Main Logic ---
COMMAND="$1"
KEY="$2"
VALUE="$3"

case "$COMMAND" in
    get)
        get_value "$KEY"
        ;;
    set)
        if [ -z "$KEY" ] || [ -z "$VALUE" ]; then
            log "ERROR: Usage: config.sh set <key> <value>"
            echo "Error: Usage: config.sh set <key> <value>" >&2
            exit 1
        fi
        set_value "$KEY" "$VALUE"
        ;;
    *)
        log "ERROR: Invalid command. Usage: config.sh [get|set] <key> [<value>]"
        echo "Error: Invalid command. Usage: config.sh [get|set] <key> [<value>]" >&2
        exit 1
        ;;
esac

exit 0