#!/system/bin/sh
# SpeedCool v2.3 - Service Initializer (service.sh)
# Author: Llucs

. ${0%/*}/../common/functions.sh

log "Starting SpeedCool v2.3 service..."

# Ensure root permissions
[ "$(id -u)" -ne 0 ] && {
  echo "❌ Root access is required to run." >&2
  exit 1
}

# Wait for boot completion with a safety timeout
log "Waiting for the system to complete boot..."
for i in $(seq 1 30); do
  BOOT=$(getprop sys.boot_completed)
  [ "$BOOT" = "1" ] && break
  sleep 2
done

if [ "$BOOT" != "1" ]; then
  log "⏳ Boot not confirmed after 60s. Continuing anyway..."
fi

load_user_config
check_kernel_features

log "Setting permissions and directories..."
mkdir -p "$MODDIR/configs" "$MODDIR/configs/backup"

# Set essential permissions
chmod -R 0700 "$MODDIR/scripts" 2>/dev/null
chmod 0700 "$MODDIR/common/functions.sh" 2>/dev/null
chmod 0600 "$MODDIR/configs/"*.conf "$MODDIR/settings.conf" 2>/dev/null

# Start scripts only if they are not already running
start_script_if_not_running() {
  local name="$1"
  local path="$MODDIR/scripts/$name"
  if ! pgrep -f "$path" >/dev/null; then
    nohup "$path" >/dev/null 2>&1 &
    log "✓ Script $name started"
  else
    log "↪ Script $name is already running"
  fi
}

log "Starting components..."
start_script_if_not_running performance.sh
start_script_if_not_running cooling.sh
start_script_if_not_running learning_engine.sh
start_script_if_not_running anti-conflito.sh

# Notification
notify_user "SpeedCool v2.3 active and running! 🚀"

# Create Termux alias
ALIAS_CMD="alias speedcool=\'sh $MODDIR/scripts/menu.sh\'"
for file in \
  /data/data/com.termux/files/home/.bashrc \
  /data/data/com.termux/files/home/.zshrc \
  /data/data/com.termux/files/home/.profile; do
    [ -f "$file" ] && ! grep -q "speedcool=" "$file" && echo "$ALIAS_CMD" >> "$file" && \
    log "Alias added to $file"
done

log "✅ SpeedCool service completed successfully."
exit 0