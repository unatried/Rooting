# v1.2.1
* Add close button

# v1.2.0
* Add multi-user support (@antoniu200)
* refactor UserID selection and function
* layout of UserID dropdown menu

# v1.1.0
* Add support for Android Binary XML (ABX)
* Change backup XML location to /sdcard/

# v1.0.0
* Initial Release