#!/system/bin/sh
############################################
# mix-mount uninstall.sh
# Cleanup script for metamodule removal
############################################

rm -rf "/data/adb/hybrid-mount"

exit 0
